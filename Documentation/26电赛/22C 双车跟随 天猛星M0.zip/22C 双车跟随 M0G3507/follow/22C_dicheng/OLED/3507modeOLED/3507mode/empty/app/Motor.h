#ifndef __PWM_H
#define __PWM_H
#include "ti_msp_dl_config.h"

#define  PI 3.1415926f
//轮子转一圈编码数
#define  encoder_onequan 364.0f 
//轮子直径 65mm
#define  MOTOR_WHEEL_D 65.0f

void Motor_SetSpeed(int left_speed, int right_speed);
float real_speed(uint8_t motor_choose);
float real_distance(void);
//#define AIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(Motor_left_PORT,Motor_left_AIN1_PIN)) : (DL_GPIO_clearPins(Motor_left_PORT,Motor_left_AIN1_PIN)) )
//#define AIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(Motor_left_PORT,Motor_left_AIN2_PIN)) : (DL_GPIO_clearPins(Motor_left_PORT,Motor_left_AIN2_PIN)) )

//#define BIN1_OUT(X)  ( (X) ? (DL_GPIO_setPins(Motor_right_PORT,Motor_right_BIN1_PIN)) : (DL_GPIO_clearPins(Motor_right_PORT,Motor_right_BIN1_PIN)) )
//#define BIN2_OUT(X)  ( (X) ? (DL_GPIO_setPins(Motor_right_PORT,Motor_right_BIN2_PIN)) : (DL_GPIO_clearPins(Motor_right_PORT,Motor_right_BIN2_PIN)) )

#endif