#ifndef __CHAOS_H
#define __CHAOS_H

#include "headfile.h"

void chaos_init(void);
uint16_t read_chaos_value(void);
uint16_t chaos_pluserror(void);
extern uint8_t bad_count;
#endif