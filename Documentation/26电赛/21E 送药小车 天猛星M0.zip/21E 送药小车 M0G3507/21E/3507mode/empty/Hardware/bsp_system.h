#ifndef __BSP_SYSTEM_H
#define __BSP_SYSTEM_H


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include <OLED.h>
#include <key.h>
#include <menu.h>
#include <Motor.h>
#include <Xunji.h>

#include <JY.h>
#include <cam.h>
#include <maixcam.h>
#include <send.h>

extern float XunJi_Value;

extern uint8_t IT_Flag_1;

#endif
