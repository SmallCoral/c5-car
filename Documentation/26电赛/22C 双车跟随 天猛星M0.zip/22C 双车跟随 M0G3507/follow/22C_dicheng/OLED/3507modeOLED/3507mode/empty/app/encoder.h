#ifndef __ENCODER_H__
#define __ENCODER_H__
#include "headfile.h"

static void encoder_function2(void);
extern int encoder_l_count,encoder_r_count;
extern float encoder_count;
extern int encoder_left,encoder_right;
#endif