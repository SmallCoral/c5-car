#include "headfile.h"

void LED_Init(void)
{

    DL_GPIO_setPins(LED_U14_PORT, LED_U14_PIN);
    DL_GPIO_setPins(LED_U13_PORT, LED_U13_PIN);
    DL_GPIO_setPins(LED_U12_PORT, LED_U12_PIN);

}

void LED_On(LED_t led)
{
    switch (led) {
        case LED1: DL_GPIO_clearPins(LED_U14_PORT, LED_U14_PIN); break;
        case LED2: DL_GPIO_clearPins(LED_U13_PORT, LED_U13_PIN); break;
        case LED3: DL_GPIO_clearPins(LED_U12_PORT, LED_U12_PIN); break;
    }
}

void LED_Off(LED_t led)
{
    switch (led) 
    {
        case LED1: DL_GPIO_setPins(LED_U14_PORT, LED_U14_PIN); break;
        case LED2: DL_GPIO_setPins(LED_U13_PORT, LED_U13_PIN); break;
        case LED3: DL_GPIO_setPins(LED_U12_PORT, LED_U12_PIN); break;
    }
}

void LED_Toggle(LED_t led)
{
    switch (led) 
    {
        case LED1: DL_GPIO_togglePins(LED_U14_PORT, LED_U14_PIN); break;
        case LED2: DL_GPIO_togglePins(LED_U13_PORT, LED_U13_PIN); break;
        case LED3: DL_GPIO_togglePins(LED_U12_PORT, LED_U12_PIN); break;
    }
}

void LED_AllOff(void)
{
    DL_GPIO_setPins(LED_U14_PORT, LED_U14_PIN);
    DL_GPIO_setPins(LED_U13_PORT, LED_U13_PIN);
    DL_GPIO_setPins(LED_U12_PORT, LED_U12_PIN);
}

void LED_AllOn(void)
{
    DL_GPIO_clearPins(LED_U14_PORT, LED_U14_PIN);
    DL_GPIO_clearPins(LED_U13_PORT, LED_U13_PIN);
    DL_GPIO_clearPins(LED_U12_PORT, LED_U12_PIN);
}

void LED_ToggleAll(void)
{
    DL_GPIO_togglePins(LED_U14_PORT, LED_U14_PIN);
    DL_GPIO_togglePins(LED_U13_PORT, LED_U13_PIN);
    DL_GPIO_togglePins(LED_U12_PORT, LED_U12_PIN);
}
