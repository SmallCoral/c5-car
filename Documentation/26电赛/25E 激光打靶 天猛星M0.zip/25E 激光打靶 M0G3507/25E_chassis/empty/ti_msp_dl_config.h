/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000



/* Defines for PWM */
#define PWM_INST                                                           TIMG7
#define PWM_INST_IRQHandler                                     TIMG7_IRQHandler
#define PWM_INST_INT_IRQN                                       (TIMG7_INT_IRQn)
#define PWM_INST_CLK_FREQ                                                1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_C0_PORT                                                   GPIOA
#define GPIO_PWM_C0_PIN                                           DL_GPIO_PIN_26
#define GPIO_PWM_C0_IOMUX                                        (IOMUX_PINCM59)
#define GPIO_PWM_C0_IOMUX_FUNC                       IOMUX_PINCM59_PF_TIMG7_CCP0
#define GPIO_PWM_C0_IDX                                      DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_C1_PORT                                                   GPIOA
#define GPIO_PWM_C1_PIN                                           DL_GPIO_PIN_31
#define GPIO_PWM_C1_IOMUX                                         (IOMUX_PINCM6)
#define GPIO_PWM_C1_IOMUX_FUNC                        IOMUX_PINCM6_PF_TIMG7_CCP1
#define GPIO_PWM_C1_IDX                                      DL_TIMER_CC_1_INDEX



/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMA0)
#define TIMER_0_INST_IRQHandler                                 TIMA0_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMA0_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                          (9999U)



/* Defines for JY */
#define JY_INST                                                            UART3
#define JY_INST_FREQUENCY                                               80000000
#define JY_INST_IRQHandler                                      UART3_IRQHandler
#define JY_INST_INT_IRQN                                          UART3_INT_IRQn
#define GPIO_JY_RX_PORT                                                    GPIOB
#define GPIO_JY_TX_PORT                                                    GPIOB
#define GPIO_JY_RX_PIN                                             DL_GPIO_PIN_3
#define GPIO_JY_TX_PIN                                             DL_GPIO_PIN_2
#define GPIO_JY_IOMUX_RX                                         (IOMUX_PINCM16)
#define GPIO_JY_IOMUX_TX                                         (IOMUX_PINCM15)
#define GPIO_JY_IOMUX_RX_FUNC                          IOMUX_PINCM16_PF_UART3_RX
#define GPIO_JY_IOMUX_TX_FUNC                          IOMUX_PINCM15_PF_UART3_TX
#define JY_BAUD_RATE                                                    (115200)
#define JY_IBRD_80_MHZ_115200_BAUD                                          (43)
#define JY_FBRD_80_MHZ_115200_BAUD                                          (26)





/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOB)

/* Defines for PIN_0: GPIOB.22 with pinCMx 50 on package pin 21 */
#define LED_PIN_0_PIN                                           (DL_GPIO_PIN_22)
#define LED_PIN_0_IOMUX                                          (IOMUX_PINCM50)
/* Port definition for Pin Group CONNECT */
#define CONNECT_PORT                                                     (GPIOA)

/* Defines for PIN_1: GPIOA.7 with pinCMx 14 on package pin 49 */
#define CONNECT_PIN_1_PIN                                        (DL_GPIO_PIN_7)
#define CONNECT_PIN_1_IOMUX                                      (IOMUX_PINCM14)
/* Port definition for Pin Group OLED */
#define OLED_PORT                                                        (GPIOB)

/* Defines for PIN_SCL: GPIOB.9 with pinCMx 26 on package pin 61 */
#define OLED_PIN_SCL_PIN                                         (DL_GPIO_PIN_9)
#define OLED_PIN_SCL_IOMUX                                       (IOMUX_PINCM26)
/* Defines for PIN_SDA: GPIOB.8 with pinCMx 25 on package pin 60 */
#define OLED_PIN_SDA_PIN                                         (DL_GPIO_PIN_8)
#define OLED_PIN_SDA_IOMUX                                       (IOMUX_PINCM25)
/* Defines for KEY_1: GPIOA.24 with pinCMx 54 on package pin 25 */
#define KEY_KEY_1_PORT                                                   (GPIOA)
#define KEY_KEY_1_PIN                                           (DL_GPIO_PIN_24)
#define KEY_KEY_1_IOMUX                                          (IOMUX_PINCM54)
/* Defines for KEY_2: GPIOB.11 with pinCMx 28 on package pin 63 */
#define KEY_KEY_2_PORT                                                   (GPIOB)
#define KEY_KEY_2_PIN                                           (DL_GPIO_PIN_11)
#define KEY_KEY_2_IOMUX                                          (IOMUX_PINCM28)
/* Defines for KEY_3: GPIOB.1 with pinCMx 13 on package pin 48 */
#define KEY_KEY_3_PORT                                                   (GPIOB)
#define KEY_KEY_3_PIN                                            (DL_GPIO_PIN_1)
#define KEY_KEY_3_IOMUX                                          (IOMUX_PINCM13)
/* Defines for KEY_4: GPIOB.21 with pinCMx 49 on package pin 20 */
#define KEY_KEY_4_PORT                                                   (GPIOB)
#define KEY_KEY_4_PIN                                           (DL_GPIO_PIN_21)
#define KEY_KEY_4_IOMUX                                          (IOMUX_PINCM49)
/* Defines for AIN1: GPIOB.24 with pinCMx 52 on package pin 23 */
#define Motor_AIN1_PORT                                                  (GPIOB)
#define Motor_AIN1_PIN                                          (DL_GPIO_PIN_24)
#define Motor_AIN1_IOMUX                                         (IOMUX_PINCM52)
/* Defines for AIN2: GPIOB.23 with pinCMx 51 on package pin 22 */
#define Motor_AIN2_PORT                                                  (GPIOB)
#define Motor_AIN2_PIN                                          (DL_GPIO_PIN_23)
#define Motor_AIN2_IOMUX                                         (IOMUX_PINCM51)
/* Defines for BIN1: GPIOB.10 with pinCMx 27 on package pin 62 */
#define Motor_BIN1_PORT                                                  (GPIOB)
#define Motor_BIN1_PIN                                          (DL_GPIO_PIN_10)
#define Motor_BIN1_IOMUX                                         (IOMUX_PINCM27)
/* Defines for BIN2: GPIOA.13 with pinCMx 35 on package pin 6 */
#define Motor_BIN2_PORT                                                  (GPIOA)
#define Motor_BIN2_PIN                                          (DL_GPIO_PIN_13)
#define Motor_BIN2_IOMUX                                         (IOMUX_PINCM35)
/* Defines for L_3: GPIOA.27 with pinCMx 60 on package pin 31 */
#define XunJi_L_3_PORT                                                   (GPIOA)
#define XunJi_L_3_PIN                                           (DL_GPIO_PIN_27)
#define XunJi_L_3_IOMUX                                          (IOMUX_PINCM60)
/* Defines for L_2: GPIOA.25 with pinCMx 55 on package pin 26 */
#define XunJi_L_2_PORT                                                   (GPIOA)
#define XunJi_L_2_PIN                                           (DL_GPIO_PIN_25)
#define XunJi_L_2_IOMUX                                          (IOMUX_PINCM55)
/* Defines for L_1: GPIOB.25 with pinCMx 56 on package pin 27 */
#define XunJi_L_1_PORT                                                   (GPIOB)
#define XunJi_L_1_PIN                                           (DL_GPIO_PIN_25)
#define XunJi_L_1_IOMUX                                          (IOMUX_PINCM56)
/* Defines for M_2: GPIOB.20 with pinCMx 48 on package pin 19 */
#define XunJi_M_2_PORT                                                   (GPIOB)
#define XunJi_M_2_PIN                                           (DL_GPIO_PIN_20)
#define XunJi_M_2_IOMUX                                          (IOMUX_PINCM48)
/* Defines for M_1: GPIOA.14 with pinCMx 36 on package pin 7 */
#define XunJi_M_1_PORT                                                   (GPIOA)
#define XunJi_M_1_PIN                                           (DL_GPIO_PIN_14)
#define XunJi_M_1_IOMUX                                          (IOMUX_PINCM36)
/* Defines for R_1: GPIOA.16 with pinCMx 38 on package pin 9 */
#define XunJi_R_1_PORT                                                   (GPIOA)
#define XunJi_R_1_PIN                                           (DL_GPIO_PIN_16)
#define XunJi_R_1_IOMUX                                          (IOMUX_PINCM38)
/* Defines for R_2: GPIOB.17 with pinCMx 43 on package pin 14 */
#define XunJi_R_2_PORT                                                   (GPIOB)
#define XunJi_R_2_PIN                                           (DL_GPIO_PIN_17)
#define XunJi_R_2_IOMUX                                          (IOMUX_PINCM43)
/* Defines for R_3: GPIOB.19 with pinCMx 45 on package pin 16 */
#define XunJi_R_3_PORT                                                   (GPIOB)
#define XunJi_R_3_PIN                                           (DL_GPIO_PIN_19)
#define XunJi_R_3_IOMUX                                          (IOMUX_PINCM45)



/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_JY_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
