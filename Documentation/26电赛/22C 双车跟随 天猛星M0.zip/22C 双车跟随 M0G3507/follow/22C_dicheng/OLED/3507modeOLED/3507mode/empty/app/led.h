#ifndef __LED_H
#define __LED_H

#include "headfile.h"
/* LED 编号 */
typedef enum {
    LED1 = 0,
    LED2,
    LED3
} LED_t;

/* 初始化所有 LED（配置为推挽输出，初始熄灭） */
void LED_Init(void);

/* 点亮指定 LED */
void LED_On(LED_t led);

/* 熄灭指定 LED */
void LED_Off(LED_t led);

/* 翻转指定 LED */
void LED_Toggle(LED_t led);

/* 所有 LED 熄灭 */
void LED_AllOff(void);

/* 所有 LED 点亮 */
void LED_AllOn(void);

void LED_ToggleAll(void) ;
#endif