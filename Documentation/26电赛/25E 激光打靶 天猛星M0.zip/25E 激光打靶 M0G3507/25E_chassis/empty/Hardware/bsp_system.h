#ifndef __BSP_SYSTEM_H
#define __BSP_SYSTEM_H


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

#include <OLED.h>
#include <key.h>
#include <menu.h>

#include <Motor.h>
#include <Xunji.h>

#include <JY.h>

extern int IT_Flag_1;

extern float gray_error;

#endif
