#ifndef __BUZZER_H
#define __BUZZER_H

#include "headfile.h"
extern uint8_t buzzerflag ;


void buzzer_On(void);
void buzzer_Off(void);




#endif