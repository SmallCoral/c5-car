#ifndef __MENU_H
#define __MENU_H

#include "ti_msp_dl_config.h"

extern float Z_angel;;

extern int8_t func_index;


extern uint8_t Target_quan;

void menu_operation(void);

void Boot_animation(void);
void Homepage_1(void);
void Homepage_2(void);


#endif

