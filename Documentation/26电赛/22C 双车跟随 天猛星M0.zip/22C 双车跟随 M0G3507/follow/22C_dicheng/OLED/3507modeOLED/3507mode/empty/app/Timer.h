#ifndef __TIMER_H
#define __TIMER_H
#include "ti_msp_dl_config.h"

void Timer_Init();
extern float real_l_speed,real_r_speed;
extern uint16_t chaos,old_chaos;
extern uint8_t a,chaos_flag;
#endif
