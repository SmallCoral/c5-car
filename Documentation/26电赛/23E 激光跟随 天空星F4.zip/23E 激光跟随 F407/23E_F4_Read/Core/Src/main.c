/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include <bsp_system.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

char t_buffer[80];

int16_t speed = 40;  /* 最慢速度可达8000  */

uint16_t tim = 0;

uint8_t quan_flag = 0;

uint8_t IT_tim_1 = 0;

uint8_t IT_tim_2 = 0;

uint8_t IT_tim_3 = 0;



/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM1_Init();
  MX_USART2_UART_Init();
  MX_TIM4_Init();
  MX_TIM3_Init();
  MX_USART3_UART_Init();
  MX_USART6_UART_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */
	
	OLED_Init();
	
	
	//初始化maxicam的数据
	Buffer_Init();
	Maxicam_Init();
	
	//初始化电机X
	Motor_X_Init();

  //初始化电机Y
  Motor_Y_Init();
	
//	//初始化蓝牙
	LY_Init();

	HAL_TIM_Base_Start_IT(&htim1);
	
	

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
	//从X_3出快速回到归零点
	// Contron_X_Position(1, 10, 30, false);
	 
	 
	//Contron_Y_Position(0, 10, 50, false);
	
	

  while (1)
  {
			
		xunji_state_now();  //改变寻址目标的状态的函数
		
		menu_operation();
		
		motor_complete_data();   //处理接收到的X电机数
		
		motor_complete_data_Y();
		
		Complete_LY_Data();
		
		
		K_calculate();
		
		
	   
		
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 84;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */



void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	
	
//	//每隔10us进入一次专门用于控制X电机
//	if (htim == &htim2) {
//		
//		
//		Stepper_TickCallback_X(&motor_X);
//		
//			if (__HAL_TIM_GET_FLAG(&htim2, TIM_FLAG_UPDATE) == 1) {
//			
//				IT_tim_2  = 1;
//				__HAL_TIM_CLEAR_FLAG(&htim2, TIM_FLAG_UPDATE);
//		}
//	}
//	
//	//每隔10us进入一次专门用于控制Y电机
//	if (htim == &htim3) {
//		
//		Stepper_TickCallback_Y(&motor_Y);
//		
//			if (__HAL_TIM_GET_FLAG(&htim3, TIM_FLAG_UPDATE) == 1) {
//			
//				IT_tim_3  = 1;
//				__HAL_TIM_CLEAR_FLAG(&htim3, TIM_FLAG_UPDATE);
//		}
//				
//	}

	static uint8_t tdata_tim = 0;
	
	static uint8_t control = 0;
	
	static uint8_t time_1_count = 0;  //用于稳定起始点
	
	static uint8_t time_3_count = 0;  //用于稳定X_3点
		
	static uint8_t time_2_count = 0;  //用于稳定X_2点
	
	static uint8_t time11_count = 0;
			
	
	//每10ms进入一次中断
	if (htim == &htim1) {
		
		
		tdata_tim++;
		
		
		
		
		//基础部分第二问
		base_invisible();


		//每隔10ms读取一道Contron_X_Speed(0, 1);
		key_tick();
		
		
		//每隔10ms读取一次maxicam数据
			Maxicam_Data_Handle();
		
		//用于稳定X_0初始位置
		if (time_flag == 1) {
			
			time_1_count++;
			if (time_1_count >= 120) {
				
				xunji_taget = 5;  //稳定了后开始追踪
				xunji_state = 1;  //目标：到达X_3处时候可以在此点稳定住
				time_flag = 0;   //一定要记得清除
			}
		}
		else if (time_flag == 0) {
			
			time_1_count = 0;
		}
		
		//用于稳定X_3初始位置
			if (time_flag_3 == 1) {
			
			time_3_count++;
			if (time_3_count >= 120) {
				
        xunji_state = 2;
				xunji_taget = 5;
				time_flag_3 = 0;
				
			}
		}
		else if (time_flag_3 == 0) {
			
			time_3_count = 0;
		}
		
				//用于稳定X_2初始位置
			if (time_flag_2 == 1) {
			
			time_2_count++;
			if (time_2_count >= 120) {
				
        xunji_state = 3;
				xunji_taget = 5;
				time_flag_2 = 0;
				
			}
		}
		else if (time_flag_2 == 0) {
			
			time_2_count = 0;
		}
		
			//用于稳定X_1初始位置
			if (time_flag_1 == 1) {
			
			time11_count++;
			if (time11_count >= 120) {
				
        xunji_state = 4;
				xunji_taget = 5;
				time_flag_1 = 0;
				
			}
		}
		else if (time_flag_1 == 0) {
			
			time11_count = 0;
		}
		
		
		
		//由于电机没执行以此发送的 指令才会进行接收下一次执行命令，所以发送太快用处也不大
		if (xunji_stop == 0) {
			
			control++;
			if (control >= 10) {
			
				control = 0;
				xunji_black_X();
				xunji_black_Y();
			}
		}
		
		if (tdata_tim >= 5) {
			
			tdata_tim = 0;
		sprintf(t_buffer, "%.1f,%.1f,%.1f,%.1f,%.1f,%.1f\r\n", pid_shot_X.Target, pid_shot_X.Actual , pid_shot_Y.Target, pid_shot_Y.Actual, pid_shot_X.Out, pid_shot_Y.Out);
//				sprintf(t_buffer, "%d,%d\r\n", X_step, Y_step);
			//sprintf(t_buffer, "%.1f,%.1f,%.1f\r\n", pid_line_K.Out, pid_line_K.Target, pid_line_K.Actual);
			HAL_UART_Transmit_DMA(&huart4, (uint8_t*)t_buffer, strlen(t_buffer));
		}
		
		if (__HAL_TIM_GET_FLAG(&htim1, TIM_FLAG_UPDATE) == 1) {
			
				IT_tim_1 = 1;
				__HAL_TIM_CLEAR_FLAG(&htim1, TIM_FLAG_UPDATE);
		}
		
	}
	
	
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
