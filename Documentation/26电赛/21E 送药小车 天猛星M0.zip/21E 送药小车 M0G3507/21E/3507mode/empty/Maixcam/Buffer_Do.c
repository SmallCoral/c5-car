#include <Buffer_Do.h>
#include <maixcam.h>
#include <string.h>

/*

左转： AA 04 00 01 00 00 00 05 55
右转:  AA 04 00 02 00 00 00 06 55


帧头: AA  数据域长度： 04 00 (小端格式)  数据域: 01 00 00 00 (小端格式)  05（校验和 04 + 00 + 00 + 00 + 00 + 01)  55包尾


*/

#define HEAD 0xAA
#define HEAD_ONE  0x04   //这里不特殊处理， 就把0x04当作第二个包头
#define TRAIL 0x55

#define MAXICAM_PACKET_SIZE 9

/*

//函数功能：校验数据包， 返回包头前赘余数据
//若未检测到数据包则返回-1, 若出去赘余数据后传入的数据长度不足一个基本的数据包返回-2, 若未检测到包尾则返回-3
int32_t verify_Pack(uint8_t *buffer, uint8_t length, uint16_t  *redundant ) {
	
	uint8_t head_flag = 0;
	
	//未检测到数据包返回-1, 注意这里buffer千万不能加*, 因为*buffer == NULL根据c语言可以理解为*buffer == 0;
	if ((buffer == NULL) || (length == 0) || ( redundant == NULL)) {
		return -1;
	}
	
	uint16_t index = 0;
	for (int index = 0; index < length; index++) {
		
		
		//问题是现在检测不到数据包？？？, 注意maxicam在上电后会发送大量的初始化数据使得缓冲区被填满
		if ((buffer[index] != HEAD) || (buffer[index+1] != HEAD_ONE) )
			{
			
			//问题点，在for循环中已经进行了index++了，再在此处会有影响
			//index++;
		}
		
		//若检测到包头，直接推出for循环
		else {
			
			head_flag = 1;  //表示检测到包头
			break;
		}
	}
	
//	if (index == 0) {
//		
//		*redundant = index;
//	}
//	else {		
//	*redundant = index - 1;}  //获取赘余数的总索引， 这里将包头加载索引中,但是删除数据时候不包含包头, 因为索引是从0开始的
	
	*redundant = index;
	
	//当检测到包头后，看看包头后面的数据包是否完整
	if (head_flag == 1) {
		
	//情况一：数据长度不够，返回-2继续往后接收数据
	if ((length - index) <23) {
		return -2;
	}
	
	//情况二：数据包包尾错误返回-3
	if (buffer[index+22] != 0x17 ) {
		return -3;
	}
	
	//情况三：数据包无错误，返回0
	return 0; 
}
	else {
		
		//情况四：在缓冲区已接收到的数据中没有发现数据包的包头,返回-4
		return -4;
	}
	
}

*/


int32_t verify_Pack(uint8_t *buffer, uint8_t length, uint16_t  *redundant ) {
	
    if (buffer == NULL || length == 0 || redundant == NULL){
			return -1;
		}
    
		
    for (uint32_t i = 0; i < length - 1; i++) {
			
        if (buffer[i] == HEAD && buffer[i+1] == HEAD_ONE) {
            *redundant = i;   // 冗余字节数
					
					// 数据不足
            if (length - i < 9) {
							return -2; }
					
					// 包尾错误
            if (buffer[i+8] != TRAIL) {
							return -3;    }
					
            return 0;                                 // 成功
        }
    }
    // 未找到包头，返回 -1（格式错误）
    *redundant = length; // 可忽略
    return -1;
}



/*
 * 解码出数据负载部分
 * 返回值： 负载内容长度，错误时返回-1
 */

//解码一个自定义格式的数据包，提取有效载荷（payload）到指定缓冲区
//1.//&buffer[redundant]表示有效数据的地址
//2.有效数据长度
//3.有效数据存放的数组
//4.有效数据的长度
int32_t packet_decode(uint8_t* data, uint32_t len, uint8_t* payload_buff, uint32_t buff_len)

{
	if((data == NULL) || (data[0] != HEAD) || (len < 9) || (payload_buff == NULL) || (buff_len < 9)){
		return -1;
	}
	
	
	
	memcpy(payload_buff, &data[0], MAXICAM_PACKET_SIZE);  //将一个完整的数据包赋值出去
	return 0;
}

