#include "headfile.h"

int encoder_l_count,encoder_r_count;
float encoder_count;
int encoder_left,encoder_right;//记路程
	
void GROUP1_IRQHandler(void)
{
switch(DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1))
{
	case DL_INTERRUPT_GROUP1_IIDX_GPIOB:
	{	
	encoder_function2();
	}
  break; 
	
	
	default:
		break;
}
}	




static void encoder_function2(void)
{
    //处理左编码器A相中断,A相上升沿
    if (DL_GPIO_getEnabledInterruptStatus(encoder_left_A_PORT, encoder_left_A_PIN))
    {
        if(DL_GPIO_readPins(encoder_left_B_PORT, encoder_left_B_PIN)==0)    //B逻辑低
        {
            encoder_l_count--;  //计数增
					  encoder_left--;
        }
        else
        {
            encoder_l_count++; //计数减
            encoder_left++;
				}
        // 清除A相的中断状态
        DL_GPIO_clearInterruptStatus(encoder_left_A_PORT, encoder_left_A_PIN);
    }
		
		
		    //处理右编码器A相中断,A相上升沿
    if (DL_GPIO_getEnabledInterruptStatus(encoder_right_A_PORT, encoder_right_A_PIN))
    {
        if(DL_GPIO_readPins(encoder_right_B_PORT, encoder_right_B_PIN)==0)    //B逻辑低
        {
            encoder_r_count++;  //计数增
					  encoder_right++;
        }
        else
        {
            encoder_r_count--; //计数减
					  encoder_right--;
        }
        // 清除A相的中断状态
        DL_GPIO_clearInterruptStatus(encoder_right_A_PORT, encoder_right_A_PIN);
    }
}		
		
	