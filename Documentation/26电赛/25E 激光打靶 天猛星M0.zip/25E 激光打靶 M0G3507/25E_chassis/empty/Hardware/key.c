#include "key.h"
#include "BSP_SYSTEM.h"
typedef struct {
	
	uint32_t key_sta;
	uint32_t key_jude;
	uint32_t key_single;
	
	uint32_t key_press;
	uint32_t key_long;
	
}keys;

keys key[4];


uint8_t key_proc(void) {
	
	uint8_t temp = 0;
	
	if (key[0].key_single == 1) {
		
		key[0].key_single = 0;
		temp = 1;
		return temp;
	}
	
	if (key[1].key_single == 1) {
		
		key[1].key_single = 0;
		temp = 2;
		return temp;
	}
	
	
	if (key[2].key_single == 1) {
		
		key[2].key_single = 0;
		temp = 3;
		return temp;
	}
	
	
	if (key[3].key_single == 1) {
		
		key[3].key_single = 0;
		temp = 4;
		return temp;
	}
	
	return 0;
}


void key_tick(void) {
	
	int i;
	
	key[0].key_sta = DL_GPIO_readPins(KEY_KEY_1_PORT, KEY_KEY_1_PIN);
	key[1].key_sta = DL_GPIO_readPins(KEY_KEY_2_PORT, KEY_KEY_2_PIN);
	key[2].key_sta = DL_GPIO_readPins(KEY_KEY_3_PORT, KEY_KEY_3_PIN);
	key[3].key_sta = DL_GPIO_readPins(KEY_KEY_4_PORT, KEY_KEY_4_PIN);
	
	for ( i = 0; i < 4; i++) {
		
	switch (key[i].key_jude) {
		
		case 0:
			
		if(key[i].key_sta == 0) {
			
			key[i].key_jude = 1;
		}		
		break;
		
		case 1:
			
		if (key[i].key_sta == 0) {
			
			key[i].key_press = 0;
			key[i].key_long = 0;
			
			key[i].key_jude = 2;
		}		
		else {
			key[i].key_jude = 0;   //别忘记了
		}
		break;
		
		case 2:
			
		if (key[i].key_sta != 0) {
			
			if (key[i].key_long == 0) {
				
				key[i].key_single = 1;
			}
			else if (key[i].key_long == 1) {
				
				key[i].key_long = 0;
				
				
				//shot_bengin = !shot_bengin;

			}
			
			key[i].key_jude = 0;   //释放按键标志位
		}
		
		else {
			
			if (key[2].key_sta == 0 && i == 2) {
				
				key[2].key_press++;
				if (key[2].key_press >= 100) {
					
					key[2].key_long = 1;
				}
			}
			
		}		
		break;
		
	}
	
	
	
	}
	
}


