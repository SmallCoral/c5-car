#ifndef __SEND_H__
#define __SEND_H__


#include "ti_msp_dl_config.h"
#include  "Xunji.h"

//送药房间
typedef enum {

		NONE_ROOM = 0,   //没有检测到需要发送的房间
    ROOM_ONE   = 1,
    ROOM_TOW  = 2,
    ROOM_THREE = 3,
		ROOM_FOUR = 4,
		ROOM_FIVE = 5,
		ROOM_SIX = 6,
		ROOM_SEVEN = 7,
		ROOM_EIGHT = 8,
		ROOM_NINE = 9,
} Pharmacy;


//小车巡线逻辑
typedef enum {

	NONE_DATE = 0,
	WAIT_TURN_RIGHT = 1,	//右转
	WAIT_TURN_LEFT = 2,	//左转
	COMPLET_TURN = 3,	//完成转弯
	
	ERROR_DATA = 4,

} Position;


//小车巡线模式
typedef enum {
	
	FETCH_ROOM = 0,  //等待药品
	GO_SEND = 1,  //放上药品开始送药
	WAIT_COME_BACK = 2,  //药品送完， 小车返回
	GRAY_LINE = 3,  //灰度巡行状态
	WAIT_GRAY_STOP = 4,  //灰度巡行停止状态
	COMPLET_GRAY_STOP = 5,  //灰度巡行完成停止状态
	GRAY_IN_TUEN = 6,  // 处于转弯中
	GRAY_TURN_OVER = 7,  //转弯完成
	
	BEGAIN_COME_BACK = 8,
	
} Pattern;


extern Position CAM_COMMAD;
extern Pattern XUN_COMMAD;

extern uint16_t send_delay_begain;
extern uint8_t  send_delay_use;

extern uint16_t car_turn_delay_begain;
extern uint8_t  car_turn_delay_use;

extern uint16_t car_gray_delay_begain;
extern uint8_t  car_gray_delay_use;

//计数走过了那些病房
extern uint8_t gray_count_begain;
extern uint8_t room_state;

extern float Angle_Bias;

extern uint32_t medicine_in;

extern uint8_t last_Turn;  //储存第一次转弯的数值

extern PID_XunJi Turn_Down;
extern PID_XunJi come_back;
extern PID_XunJi turn_come_back;

void distance_room( float demonitor);  //计数，走过的病房

void load_medicine(void);

void Gray_Stop(float denominator);

void Car_Turn(void);

void Send_Room(void);


void PID_Spin(PID_XunJi* p);

void swing_vision(void);  //左右摆动函数


/*------------返回函数-----------*/

void arrive_stop(float demonitor, float last_demonitor, uint8_t i_max, uint8_t i_min);

void car_Trun_Down(void);

void car_come_back(void);

void come_back_pattern_change(float demonitor);

void last_state(void);


#endif
