/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000



/* Defines for PWM_0 */
#define PWM_0_INST                                                         TIMG7
#define PWM_0_INST_IRQHandler                                   TIMG7_IRQHandler
#define PWM_0_INST_INT_IRQN                                     (TIMG7_INT_IRQn)
#define PWM_0_INST_CLK_FREQ                                             10000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_0_C0_PORT                                                 GPIOA
#define GPIO_PWM_0_C0_PIN                                         DL_GPIO_PIN_26
#define GPIO_PWM_0_C0_IOMUX                                      (IOMUX_PINCM59)
#define GPIO_PWM_0_C0_IOMUX_FUNC                     IOMUX_PINCM59_PF_TIMG7_CCP0
#define GPIO_PWM_0_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_0_C1_PORT                                                 GPIOA
#define GPIO_PWM_0_C1_PIN                                         DL_GPIO_PIN_31
#define GPIO_PWM_0_C1_IOMUX                                       (IOMUX_PINCM6)
#define GPIO_PWM_0_C1_IOMUX_FUNC                      IOMUX_PINCM6_PF_TIMG7_CCP1
#define GPIO_PWM_0_C1_IDX                                    DL_TIMER_CC_1_INDEX

/* Defines for PWM_chaos */
#define PWM_chaos_INST                                                     TIMG8
#define PWM_chaos_INST_IRQHandler                               TIMG8_IRQHandler
#define PWM_chaos_INST_INT_IRQN                                 (TIMG8_INT_IRQn)
#define PWM_chaos_INST_CLK_FREQ                                           320000
/* GPIO defines for channel 0 */
#define GPIO_PWM_chaos_C0_PORT                                             GPIOA
#define GPIO_PWM_chaos_C0_PIN                                      DL_GPIO_PIN_1
#define GPIO_PWM_chaos_C0_IOMUX                                   (IOMUX_PINCM2)
#define GPIO_PWM_chaos_C0_IOMUX_FUNC                  IOMUX_PINCM2_PF_TIMG8_CCP0
#define GPIO_PWM_chaos_C0_IDX                                DL_TIMER_CC_0_INDEX



/* Defines for CAPTURE_chaos */
#define CAPTURE_chaos_INST                                               (TIMG6)
#define CAPTURE_chaos_INST_IRQHandler                           TIMG6_IRQHandler
#define CAPTURE_chaos_INST_INT_IRQN                             (TIMG6_INT_IRQn)
#define CAPTURE_chaos_INST_LOAD_VALUE                                   (49999U)
/* GPIO defines for channel 0 */
#define GPIO_CAPTURE_chaos_C0_PORT                                         GPIOA
#define GPIO_CAPTURE_chaos_C0_PIN                                 DL_GPIO_PIN_21
#define GPIO_CAPTURE_chaos_C0_IOMUX                              (IOMUX_PINCM46)
#define GPIO_CAPTURE_chaos_C0_IOMUX_FUNC             IOMUX_PINCM46_PF_TIMG6_CCP0





/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMG0)
#define TIMER_0_INST_IRQHandler                                 TIMG0_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMG0_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                           (999U)



/* Defines for LY */
#define LY_INST                                                            UART0
#define LY_INST_FREQUENCY                                               40000000
#define LY_INST_IRQHandler                                      UART0_IRQHandler
#define LY_INST_INT_IRQN                                          UART0_INT_IRQn
#define GPIO_LY_RX_PORT                                                    GPIOA
#define GPIO_LY_TX_PORT                                                    GPIOA
#define GPIO_LY_RX_PIN                                            DL_GPIO_PIN_11
#define GPIO_LY_TX_PIN                                             DL_GPIO_PIN_0
#define GPIO_LY_IOMUX_RX                                         (IOMUX_PINCM22)
#define GPIO_LY_IOMUX_TX                                          (IOMUX_PINCM1)
#define GPIO_LY_IOMUX_RX_FUNC                          IOMUX_PINCM22_PF_UART0_RX
#define GPIO_LY_IOMUX_TX_FUNC                           IOMUX_PINCM1_PF_UART0_TX
#define LY_BAUD_RATE                                                      (9600)
#define LY_IBRD_40_MHZ_9600_BAUD                                           (260)
#define LY_FBRD_40_MHZ_9600_BAUD                                            (27)





/* Port definition for Pin Group buzzer */
#define buzzer_PORT                                                      (GPIOB)

/* Defines for PIN_1: GPIOB.27 with pinCMx 58 on package pin 29 */
#define buzzer_PIN_1_PIN                                        (DL_GPIO_PIN_27)
#define buzzer_PIN_1_IOMUX                                       (IOMUX_PINCM58)
/* Defines for U14: GPIOB.22 with pinCMx 50 on package pin 21 */
#define LED_U14_PORT                                                     (GPIOB)
#define LED_U14_PIN                                             (DL_GPIO_PIN_22)
#define LED_U14_IOMUX                                            (IOMUX_PINCM50)
/* Defines for U13: GPIOA.15 with pinCMx 37 on package pin 8 */
#define LED_U13_PORT                                                     (GPIOA)
#define LED_U13_PIN                                             (DL_GPIO_PIN_15)
#define LED_U13_IOMUX                                            (IOMUX_PINCM37)
/* Defines for U12: GPIOA.7 with pinCMx 14 on package pin 49 */
#define LED_U12_PORT                                                     (GPIOA)
#define LED_U12_PIN                                              (DL_GPIO_PIN_7)
#define LED_U12_IOMUX                                            (IOMUX_PINCM14)
/* Port definition for Pin Group OLED */
#define OLED_PORT                                                        (GPIOB)

/* Defines for PIN_SCL: GPIOB.9 with pinCMx 26 on package pin 61 */
#define OLED_PIN_SCL_PIN                                         (DL_GPIO_PIN_9)
#define OLED_PIN_SCL_IOMUX                                       (IOMUX_PINCM26)
/* Defines for PIN_SDA: GPIOB.8 with pinCMx 25 on package pin 60 */
#define OLED_PIN_SDA_PIN                                         (DL_GPIO_PIN_8)
#define OLED_PIN_SDA_IOMUX                                       (IOMUX_PINCM25)
/* Defines for motor_AIN1_PORT: GPIOB.24 with pinCMx 52 on package pin 23 */
#define motor_PORT_motor_AIN1_PORT_PORT                                  (GPIOB)
#define motor_PORT_motor_AIN1_PORT_PIN                          (DL_GPIO_PIN_24)
#define motor_PORT_motor_AIN1_PORT_IOMUX                         (IOMUX_PINCM52)
/* Defines for motor_AIN2_PORT: GPIOB.23 with pinCMx 51 on package pin 22 */
#define motor_PORT_motor_AIN2_PORT_PORT                                  (GPIOB)
#define motor_PORT_motor_AIN2_PORT_PIN                          (DL_GPIO_PIN_23)
#define motor_PORT_motor_AIN2_PORT_IOMUX                         (IOMUX_PINCM51)
/* Defines for motor_BIN1_PORT: GPIOB.10 with pinCMx 27 on package pin 62 */
#define motor_PORT_motor_BIN1_PORT_PORT                                  (GPIOB)
#define motor_PORT_motor_BIN1_PORT_PIN                          (DL_GPIO_PIN_10)
#define motor_PORT_motor_BIN1_PORT_IOMUX                         (IOMUX_PINCM27)
/* Defines for motor_BIN2_PORT: GPIOA.13 with pinCMx 35 on package pin 6 */
#define motor_PORT_motor_BIN2_PORT_PORT                                  (GPIOA)
#define motor_PORT_motor_BIN2_PORT_PIN                          (DL_GPIO_PIN_13)
#define motor_PORT_motor_BIN2_PORT_IOMUX                         (IOMUX_PINCM35)
/* Defines for xunji1: GPIOA.27 with pinCMx 60 on package pin 31 */
#define xunji_xunji1_PORT                                                (GPIOA)
#define xunji_xunji1_PIN                                        (DL_GPIO_PIN_27)
#define xunji_xunji1_IOMUX                                       (IOMUX_PINCM60)
/* Defines for xunji2: GPIOA.25 with pinCMx 55 on package pin 26 */
#define xunji_xunji2_PORT                                                (GPIOA)
#define xunji_xunji2_PIN                                        (DL_GPIO_PIN_25)
#define xunji_xunji2_IOMUX                                       (IOMUX_PINCM55)
/* Defines for xunji3: GPIOB.25 with pinCMx 56 on package pin 27 */
#define xunji_xunji3_PORT                                                (GPIOB)
#define xunji_xunji3_PIN                                        (DL_GPIO_PIN_25)
#define xunji_xunji3_IOMUX                                       (IOMUX_PINCM56)
/* Defines for xunji4: GPIOB.20 with pinCMx 48 on package pin 19 */
#define xunji_xunji4_PORT                                                (GPIOB)
#define xunji_xunji4_PIN                                        (DL_GPIO_PIN_20)
#define xunji_xunji4_IOMUX                                       (IOMUX_PINCM48)
/* Defines for xunji5: GPIOA.14 with pinCMx 36 on package pin 7 */
#define xunji_xunji5_PORT                                                (GPIOA)
#define xunji_xunji5_PIN                                        (DL_GPIO_PIN_14)
#define xunji_xunji5_IOMUX                                       (IOMUX_PINCM36)
/* Defines for xunji6: GPIOA.16 with pinCMx 38 on package pin 9 */
#define xunji_xunji6_PORT                                                (GPIOA)
#define xunji_xunji6_PIN                                        (DL_GPIO_PIN_16)
#define xunji_xunji6_IOMUX                                       (IOMUX_PINCM38)
/* Defines for xunji7: GPIOB.17 with pinCMx 43 on package pin 14 */
#define xunji_xunji7_PORT                                                (GPIOB)
#define xunji_xunji7_PIN                                        (DL_GPIO_PIN_17)
#define xunji_xunji7_IOMUX                                       (IOMUX_PINCM43)
/* Defines for xunji8: GPIOB.19 with pinCMx 45 on package pin 16 */
#define xunji_xunji8_PORT                                                (GPIOB)
#define xunji_xunji8_PIN                                        (DL_GPIO_PIN_19)
#define xunji_xunji8_IOMUX                                       (IOMUX_PINCM45)
/* Defines for KEY1: GPIOA.24 with pinCMx 54 on package pin 25 */
#define KEY_KEY1_PORT                                                    (GPIOA)
#define KEY_KEY1_PIN                                            (DL_GPIO_PIN_24)
#define KEY_KEY1_IOMUX                                           (IOMUX_PINCM54)
/* Defines for KEY2: GPIOB.11 with pinCMx 28 on package pin 63 */
#define KEY_KEY2_PORT                                                    (GPIOB)
#define KEY_KEY2_PIN                                            (DL_GPIO_PIN_11)
#define KEY_KEY2_IOMUX                                           (IOMUX_PINCM28)
/* Defines for KEY3: GPIOB.1 with pinCMx 13 on package pin 48 */
#define KEY_KEY3_PORT                                                    (GPIOB)
#define KEY_KEY3_PIN                                             (DL_GPIO_PIN_1)
#define KEY_KEY3_IOMUX                                           (IOMUX_PINCM13)
/* Defines for KEY4: GPIOB.21 with pinCMx 49 on package pin 20 */
#define KEY_KEY4_PORT                                                    (GPIOB)
#define KEY_KEY4_PIN                                            (DL_GPIO_PIN_21)
#define KEY_KEY4_IOMUX                                           (IOMUX_PINCM49)
/* Defines for left_A: GPIOB.12 with pinCMx 29 on package pin 64 */
#define encoder_left_A_PORT                                              (GPIOB)
// pins affected by this interrupt request:["left_A","right_A"]
#define encoder_INT_IRQN                                        (GPIOB_INT_IRQn)
#define encoder_INT_IIDX                        (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define encoder_left_A_IIDX                                 (DL_GPIO_IIDX_DIO12)
#define encoder_left_A_PIN                                      (DL_GPIO_PIN_12)
#define encoder_left_A_IOMUX                                     (IOMUX_PINCM29)
/* Defines for right_A: GPIOB.18 with pinCMx 44 on package pin 15 */
#define encoder_right_A_PORT                                             (GPIOB)
#define encoder_right_A_IIDX                                (DL_GPIO_IIDX_DIO18)
#define encoder_right_A_PIN                                     (DL_GPIO_PIN_18)
#define encoder_right_A_IOMUX                                    (IOMUX_PINCM44)
/* Defines for left_B: GPIOA.22 with pinCMx 47 on package pin 18 */
#define encoder_left_B_PORT                                              (GPIOA)
#define encoder_left_B_PIN                                      (DL_GPIO_PIN_22)
#define encoder_left_B_IOMUX                                     (IOMUX_PINCM47)
/* Defines for right_B: GPIOA.17 with pinCMx 39 on package pin 10 */
#define encoder_right_B_PORT                                             (GPIOA)
#define encoder_right_B_PIN                                     (DL_GPIO_PIN_17)
#define encoder_right_B_IOMUX                                    (IOMUX_PINCM39)



/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_0_init(void);
void SYSCFG_DL_PWM_chaos_init(void);
void SYSCFG_DL_CAPTURE_chaos_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_LY_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
