#include <Xunji.h>
#include <bsp_system.h>

/*   

对于右边是 60 - 100 40°的间隔
对于左边是 60° - -40° 是100°的间隔

经过实测 0.3m/s 对应 220
0.5m/s  对应 350
1m/s 对应  右轮 680 左轮 710

*/





int16_t AveP, DifP;
uint8_t motor_state = 0;   //小车是否启动，0表示停止



/*-----------------------权值循迹-----------------------*/

int sensor[8]={0,0,0,0,0,0,0,0};  //权重
float sensor_weight[8]={12.5,6.5,3.25,-0.8,0.8,-3.25,-6.5,-12.5};  //12.5,6.5,3.75,0.0,0.0,-3.75,-6.5,-12.5; 中间得加数值

// 为什么中间得加呢？ 当你是两条线循迹时候，中间两条线在线上则视为正常巡线， 此时中间的数值也会相互抵消和为0
//当只有一条在时候便判断为有偏移，所以中间值得加

//float sensor_weight[8]={-9.5,-6.0,-3.2,1.8,-1.8,3.2,6.0,9.5};  //辅助版接线与电路板接线相反
static float last_valid_bias = 0;  //全局静态变量，仅在该文件中可用





//设定目标初始速度
void Car_setspeed(int16_t Speed)
{
	
	AveP = Speed;

}


void Xun(void) {
	
	int16_t denominator = 0;
	
	//当识别到黑线时候灯灭，输出0
	if (DL_GPIO_readPins(XunJi_L_3_PORT, XunJi_L_3_PIN) == 0) { sensor[0] = 1;} else { sensor[0] = 0;};
	if (DL_GPIO_readPins(XunJi_L_2_PORT, XunJi_L_2_PIN) == 0) { sensor[1] = 1;} else { sensor[1] = 0;};
	if (DL_GPIO_readPins(XunJi_L_1_PORT, XunJi_L_1_PIN) == 0) { sensor[2] = 1;} else { sensor[2] = 0;};
	if (DL_GPIO_readPins(XunJi_M_1_PORT, XunJi_M_1_PIN) == 0) { sensor[3] = 1;} else { sensor[3] = 0;};
	if (DL_GPIO_readPins(XunJi_M_2_PORT, XunJi_M_2_PIN) == 0) { sensor[4] = 1;} else { sensor[4] = 0;};
	if (DL_GPIO_readPins(XunJi_R_1_PORT, XunJi_R_1_PIN) == 0) { sensor[5] = 1;} else { sensor[5] = 0;};
	if (DL_GPIO_readPins(XunJi_R_2_PORT, XunJi_R_2_PIN) == 0) { sensor[6] = 1;} else { sensor[6] = 0;};
	if (DL_GPIO_readPins(XunJi_R_3_PORT, XunJi_R_3_PIN) == 0) { sensor[7] = 1;} else { sensor[7] = 0;};
	
	

}


//利用灰度传感来获得初步的循迹误差,其每次计算得权重就是偏差得角度值
float get_sensor_actual(void)
{
    float numerator = 0.0f;//权重值
    float denominator = 0.0f;//扫到黑线的灰度个数
		static float last_denominator = 0.0f;  //储存上一次扫描到的黑线个数
	
		uint8_t i_min = 7;
		uint8_t i_max = 0;
	
    
    Xun();//获取状态
	
	

    for(int i=0; i<8; i++) 
			{			
		if(sensor[i] == 1)
			{
				
				//等等i_min初始值为0呀！！！！
					if (i <= i_min) {
					
						i_min = i;
					}
				
					if (i >= i_max) {
					
						i_max = i;
					}

				
				numerator += sensor_weight[i];   
				denominator += 1.0f;//计次加一
				
				Gray_Stop(denominator);  //小车状态切换
				
				arrive_stop(denominator, last_denominator, i_max, i_min);   // 到达药房准备停车
				
				distance_room(denominator);  //计数到达哪一个病房
				
					
				if (XUN_COMMAD == BEGAIN_COME_BACK) {
					
					come_back_pattern_change(denominator); //回家模式下的转弯
				}
				
			}
            
    }
    
		//无线状态
		if (denominator == 0) {
    
			return last_valid_bias;//返回上一次的值

    }
    
	float bias = numerator / denominator;

	last_valid_bias = bias;
	last_denominator = denominator;

    return bias;
}







/*-------------PID循迹部分-----------------*/

int16_t L_P, R_P;



//外环灰度权值环
PID_XunJi gray_out = {
	
	
	.Kp = 1.8,
	.Ki = 0.0,
	.Kd = 0.5,
	
	.ErrorIntMax = 400.0,  //这里的积分限幅值是根据实际小车正常运行时候设置的
	.ErrorIntMin = -400.0,
	
	.OutMax =  80.0f,
	.OutMin = -80.0f,
};


//内环角度环
PID_XunJi gyro_inter = {
	
	.Kp = 4.0,
	.Ki = 0.0,
	.Kd = 3.0,
	
	.ErrorIntMax = 400.0,  //这里的积分限幅值是根据实际小车正常运行时候设置的
	.ErrorIntMin = -400.0,
	
	.OutMax =  180.0f,
	.OutMin = -350.0f,
};



void gyro_control_inter(void) {
	
	

	//gyro_inter.Target = 0.0f;  //目标值取0°，保证车身直线行走
	gyro_inter.Actual = JY_Angel;  //读取JY901获取实时角度值
	
	PID_Xunji_Updata_inter(&gyro_inter);
	
	DifP = (int16_t)gyro_inter.Out;

	L_P = AveP - DifP;
	R_P = AveP + DifP;
	
	Motor_Set_PWM(1, R_P);
	Motor_Set_PWM(2, L_P);
	
}


void gray_control_out(void) {
	
	
	gray_out.Target = 0.0f;
	gray_out.Actual = XunJi_Value;  //读取循迹传感器获取实时偏差值
	
	PID_Xunji_Updata_out(&gray_out);
	
	gyro_inter.Target = -gray_out.Out + Angle_Bias;
}


void PID_Xunji_Updata_inter(PID_XunJi* p) {
	
	p->Error1 = p->Error0;
	p->Error0 = p->Target - p->Actual;
	
	p->Feedforwad = p->Target - p->Last_Target;
	
	if (fabs(p->Ki) > 0.001) {
		
		p->ErrorInt += p->Error0;
	}
	else { p->ErrorInt = 0;}
	

	
	p->Out = p->Kp * p->Error0 
					+ p->Ki * p->ErrorInt 
					+ p->Kd * (p->Error0 - p->Error1);
					//-p->Kd * (p->Actual - p->Actual1);
					//+ p->Kf * p->Feedforwad;
	
	if (p->Out > p->OutMax) p->Out = p->OutMax;
	if (p->Out < p->OutMin) p->Out = p->OutMin;
	
	p->Actual1 = p->Actual;
	
	p->Last_Target = p->Target;
}






void PID_Xunji_Updata_out(PID_XunJi* p) {
	
	p->Error1 = p->Error0;
	p->Error0 = p->Target - p->Actual;
	
	if (fabs(p->Ki) > 0.001) {
		
		p->ErrorInt += p->Error0;
	}
	else { p->ErrorInt = 0;}
	

	
	p->Out = p->Kp * p->Error0 
					+ p->Ki * p->ErrorInt 
					//+ p->Kd * (p->Error0 - p->Error1);
					-p->Kd * (p->Actual - p->Actual1);
	
	if (p->Out > p->OutMax) p->Out = p->OutMax;
	if (p->Out < p->OutMin) p->Out = p->OutMin;
	
	p->Actual1 = p->Actual;
}







