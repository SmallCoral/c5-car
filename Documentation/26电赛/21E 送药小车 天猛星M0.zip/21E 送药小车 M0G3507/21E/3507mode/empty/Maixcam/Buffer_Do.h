#ifndef __BUFFER_DO
#define __BUFFER_DO

#include "ti_msp_dl_config.h"


int32_t verify_Pack(uint8_t *buffer, uint8_t length, uint16_t  *redundant );

int32_t packet_decode(uint8_t* data, uint32_t len, uint8_t* payload_buff, uint32_t buff_len);

#endif



