#include <Xunji.h>
#include <bsp_system.h>

uint8_t motor_state = 0;  //初始状态


int sensor[8]={0,0,0,0,0,0,0,0};  //权重

/*  
Kp 过小会使得小车反应过慢， 导致小车左右大幅度晃动
Kp过大由于两头的权值过大会使得小车调节力度过大，导致小车抖动

现在将Kp值加大，减小各个等之间的权值差， 观察是否可以减小摆动
*/

float sensor_weight[8]={6.4,4.8,4.00,-2.0,2.0,-4.00,-4.8,-6.5};   



static float last_valid_bias = 0;  //全局静态变量，仅在该文件中可用
int16_t L_Speed, R_Speed;
int16_t AveP, DifP;


int Run_State = 1;  //1表示在黑线上运动，0表示识别不到黑线, 默认初始状态是在黑线上
int quan_count;   //表示电机已经转过的圈数


/*-------------循迹权值计算部分-------------*/

//设定目标初始速度
void Car_setspeed(int16_t Speed)
{
	
	AveP = Speed;

}


//该函数作用于当小车行驶完指定圈数后，不在进入motor_state = 2继续转弯；
//进入motor_state = 0 停止行驶
void car_quan_count(void) {
	
	//只行驶一圈
	if (Target_quan == 1 && quan_count == 4) {
		
		motor_state = 0;
	}
	
	//行驶两圈
	else if (Target_quan == 2 && quan_count == 8) {
		
		motor_state = 0;
	}
	
	//行驶三圈
	else if (Target_quan == 3 && quan_count == 12) {
		
		motor_state = 0;
	}
	
	//行驶四圈
	else if (Target_quan == 4 && quan_count == 16) {
		
		motor_state = 0;
	}
	
	//行驶五圈
	else if (Target_quan == 5 && quan_count == 20) {
		
		motor_state = 0;
	}
	
	//条件不满足， 说明此时还未达到指定圈数， 继续进入状态2转向
	else {
		
		motor_state = 2;
	}
	
}


void Xun(void) {
	
	int16_t denominator = 0;
	
	//当识别到黑线时候灯灭，输出0
	if (DL_GPIO_readPins(XunJi_L_3_PORT, XunJi_L_3_PIN) == 0) { sensor[0] = 1;} else { sensor[0] = 0;};
	if (DL_GPIO_readPins(XunJi_L_2_PORT, XunJi_L_2_PIN) == 0) { sensor[1] = 1;} else { sensor[1] = 0;};
	if (DL_GPIO_readPins(XunJi_L_1_PORT, XunJi_L_1_PIN) == 0) { sensor[2] = 1;} else { sensor[2] = 0;};
	if (DL_GPIO_readPins(XunJi_M_1_PORT, XunJi_M_1_PIN) == 0) { sensor[3] = 1;} else { sensor[3] = 0;};
	if (DL_GPIO_readPins(XunJi_M_2_PORT, XunJi_M_2_PIN) == 0) { sensor[4] = 1;} else { sensor[4] = 0;};
	if (DL_GPIO_readPins(XunJi_R_1_PORT, XunJi_R_1_PIN) == 0) { sensor[5] = 1;} else { sensor[5] = 0;};
	if (DL_GPIO_readPins(XunJi_R_2_PORT, XunJi_R_2_PIN) == 0) { sensor[6] = 1;} else { sensor[6] = 0;};
	if (DL_GPIO_readPins(XunJi_R_3_PORT, XunJi_R_3_PIN) == 0) { sensor[7] = 1;} else { sensor[7] = 0;};	

	
	
	
	
}


//利用灰度传感来获得初步的循迹误差,其每次计算得权重就是偏差得角度值
float get_sensor_actual(void)
{
    float numerator = 0.0f;//权重值
    float denominator = 0.0f;//扫到黑线的灰度个数

    Xun();//获取状态
	
	
    for(int i=0; i<8; i++) 
	{			
		
		//识别到黑线
		if(sensor[i] == 1)
			{
		
				numerator += sensor_weight[i];   
				denominator += 1.0f;//计次加一
				
				//此时识别到了黑线， 当上一次是白线状态此时识别到黑线才进入判断此时是黑线循迹状态并且转弯结束
				//初始状态是黑线
				if (Run_State == 0) {
					
					
					
					Run_State = 1;  

					//motor_state = 1;  不在这里进入灰度循迹状态
					//为了防止抖动， 我们只有在motor_state = 2的时候才能进入motor_state = 1的状态
					
				}
				
		}
            
    }
    
		//无线状态
		if (denominator == 0) {
			
			//只有上一次是黑线状态， 此时识别到了白线才进入转弯状态
			if (Run_State == 1) {
				
				DL_GPIO_setPins(CONNECT_PORT, CONNECT_PIN_1_PIN);  //进入转弯状态时候输出高电平
				
				quan_count++;		//设定所需运动的圈数(其实这里是转弯数加一）
				
				Run_State = 0;  //开始转弯
				
				//小车状态切换
				car_quan_count();  
												
			}
    
			return last_valid_bias;//返回上一次的值

    }
    
	float bias = numerator / denominator;
	

	last_valid_bias = bias;
		
    return bias;
}

/*---------------循迹PID计算----------------*/


PID_XunJi XunJi_PID = {//kp21  kd70
	
	.Kp = 25.0,
	.Ki = 0.0,
	.Kd = 192.0,   //192
	
	.ErrorIntMax = 400.0,  //这里的积分限幅值是根据实际小车正常运行时候设置的
	.ErrorIntMin = -400.0,
	
	.OutMax =  300.0f,
	.OutMin = -300.0f,
};




void PID_Xunji(void) {
	
			XunJi_PID.Target = 0.0f;
			XunJi_PID.Actual = gray_error;
	
			PID_Xunji_Updata(&XunJi_PID);
			DifP = (int16_t)XunJi_PID.Out;
			
			L_Speed = AveP + DifP;  
			R_Speed = AveP - DifP;
			
	//不做电机反转处理， 防止烧毁电机驱动芯片
			if (L_Speed >= 1000) L_Speed = 1000;
			if (L_Speed <= 0) L_Speed = 0;
			if (R_Speed >= 1000) R_Speed = 1000;
			if (R_Speed <= 0) R_Speed = 0;
	
			Motor_Set_PWM(1, R_Speed);        // -45 < PWM < 45 之间轮子不会转动
			Motor_Set_PWM(2, L_Speed);
	
}




/*-------------转直角弯-------------*/



PID_XunJi Turn_PID = {
	
	.Kp = 12.0,
	.Ki = 0.0,
	.Kd = 6.0,
	
	.ErrorIntMax = 400.0,  //这里的积分限幅值是根据实际小车正常运行时候设置的
	.ErrorIntMin = -400.0,
	
	.OutMax =  190.0f,
	.OutMin = -190.0f,
};



//只有在识别不到黑线的情况下才会进入转弯状态， 也就是Run_State = 0 || motor_state = 2的时候才会进入转弯状态
void Turn_Angel(void) {

	static uint8_t buffer_tim_stop = 0;
	static uint8_t buffer_stop = 1;
	static int16_t R_Speed = 0;
	static int16_t L_Speed = 0;

	//小车转弯完成后， 由于右轮速度为0 而左轮速度不为0，所以左轮加速到指定速度的视觉一定小于右轮， 导致小车会向左过冲
	static int16_t buffer_tim_begain = 0;  

	//给小车停车缓冲
	if (buffer_stop == 1) {

		
		buffer_tim_stop++;
		if (buffer_tim_stop >= 20) {

			buffer_tim_stop = 0;
			buffer_stop = 0;
		}
	}
	else if (buffer_stop == 0) {

		switch (quan_count) {
		
			case 1: Turn_PID.Target = 91.0f; break;  //左转90度
			case 2: Turn_PID.Target = 181.0f; break;  //左转180度
			case 3: Turn_PID.Target = 271.0f; break;  //左转270度
			case 4: Turn_PID.Target = 361.0f; break;  //左转360度
			case 5: Turn_PID.Target = 451.0f; break;  //左转450度
			case 6: Turn_PID.Target = 541.0f; break;  //左转540度
			case 7: Turn_PID.Target = 631.0f; break;  //左转630度
			case 8: Turn_PID.Target = 721.0f; break;  //左转720度
			case 9: Turn_PID.Target = 811.0f; break;  //左转810度
			case 10: Turn_PID.Target = 901.0f; break;  //左转900度
			case 11: Turn_PID.Target = 991.0f; break;  //左转990度
			case 12: Turn_PID.Target = 1081.0f; break;  //左转1080度
			case 13: Turn_PID.Target = 1171.0f; break;  //左转1170度
			case 14: Turn_PID.Target = 1261.0f; break;
			case 15: Turn_PID.Target = 1351.0f; break;
			case 16: Turn_PID.Target = 1441.0f; break;
			case 17: Turn_PID.Target = 1531.0f; break;
			case 18: Turn_PID.Target = 1621.0f; break;
			case 19: Turn_PID.Target = 1711.0f; break;
			case 20: Turn_PID.Target = 1801.0f; break;
		
			default: Turn_PID.Target = JY_Angle; break;  //接收到错误数据不转向
		}

		Turn_PID.Actual = JY_Angle;

		PID_Xunji_Updata(&Turn_PID);

		R_Speed = (int16_t)Turn_PID.Out;
		L_Speed = 0;

		if (fabs(Turn_PID.Target - JY_Angle) <= 4.0f) {

			//小车开车缓冲
			 R_Speed = 0;
			 L_Speed = 0;
			buffer_tim_begain++;
			if (buffer_tim_begain >= 20) {
				buffer_tim_begain = 0;
				motor_state = 1;  //转弯结束，进入循迹状态
				buffer_stop = 1;  //重新给小车停车缓冲
				
				DL_GPIO_clearPins(CONNECT_PORT, CONNECT_PIN_1_PIN); //(退出) 转弯状态时候输出高电平
				
			}

		}
	}



	Motor_Set_PWM(1, R_Speed);
	Motor_Set_PWM(2, L_Speed);

	

}





void PID_Xunji_Updata(PID_XunJi* p) {
	
	p->Error1 = p->Error0;
	p->Error0 = p->Target - p->Actual;
	
	//p->FeedForward = p->Target - p->Last_Target;  注意符号
	
	if (fabs(p->Ki) > 0.001) {
		
		p->ErrorInt += p->Error0;
	}
	else { p->ErrorInt = 0;}
	

	
	p->Out = p->Kp * p->Error0 
					+ p->Ki * p->ErrorInt 
					+ p->Kd * (p->Error0 - p->Error1);
	//-p->Kd * (p->Actual - p->Actual1);  由于电机目标值改变需要迅速抑制所以这里不采用微分先行
	
	if (p->Out > p->OutMax) p->Out = p->OutMax;
	if (p->Out < p->OutMin) p->Out = p->OutMin;
	
	p->Actual1 = p->Actual;
	
	p->Last_Target = p->Target;
}







