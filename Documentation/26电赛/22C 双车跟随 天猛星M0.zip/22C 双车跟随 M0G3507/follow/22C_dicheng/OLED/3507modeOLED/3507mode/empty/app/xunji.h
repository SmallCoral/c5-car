#ifndef __XUNJI_H__
#define __XUNJI_H__
#include "headfile.h"

uint8_t Get_OneXunJiState(uint8_t no);
uint16_t Get_AllXunJi_Value(void);
int Get_XunJi_WeightValue(void);
extern int allXunJi_value;
void LY_init(void);
extern uint8_t sensor[8];
extern int last_allXunJi_value;
void get_sensor_actual(void);
extern int leftturn_speed,rightturn_speed;
extern	uint8_t count_1,count_2,count_flag;
extern uint8_t chose_TI;
void TI_2(float denominator, uint8_t i_min, uint8_t i_max);
void TI_1(float denominator, uint8_t i_min, uint8_t i_max);
void TI_3(float denominator, uint8_t i_min, uint8_t i_max);
#endif