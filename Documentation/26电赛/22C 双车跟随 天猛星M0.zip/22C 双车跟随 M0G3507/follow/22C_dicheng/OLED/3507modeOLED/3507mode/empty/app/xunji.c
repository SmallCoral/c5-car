#include "headfile.h"

int allXunJi_value;
uint8_t sensor[8]={};
	
	uint8_t chose_state;  //选择轨道为外圈或内圈 1为外圈 2为内圈
uint8_t chose_TI;  //选择题目
int leftturn_speed,rightturn_speed;	
	uint8_t count_1,count_2,count_flag;
	
int readPinState(GPIO_Regs* port, uint32_t pin) 
{
    uint32_t state = DL_GPIO_readPins(port, pin);
    return (state & pin) ? 1 : 0;
}

uint8_t Get_OneXunJiState(uint8_t no) 
{
    switch (no)
    {	
        case 1: return readPinState(xunji_xunji1_PORT, xunji_xunji1_PIN );
        case 2: return readPinState(xunji_xunji2_PORT, xunji_xunji2_PIN );
        case 3: return readPinState(xunji_xunji3_PORT, xunji_xunji3_PIN );
        case 4: return readPinState(xunji_xunji4_PORT, xunji_xunji4_PIN );
        case 5: return readPinState(xunji_xunji5_PORT, xunji_xunji5_PIN );
        case 6: return readPinState(xunji_xunji6_PORT, xunji_xunji6_PIN );
        case 7: return readPinState(xunji_xunji7_PORT, xunji_xunji7_PIN );
        case 8: return readPinState(xunji_xunji8_PORT, xunji_xunji8_PIN );
        default: return 0;  // 处理无效输入
    }
}
// 8个传感器的合成值
uint16_t Get_AllXunJi_Value(void)
{
    int i = 0;
    uint16_t allXunJi_value = 0;
    
    for(i = 0; i < 8; i++)
    {
        // 读取当前传感器值
        uint8_t sensorValue = Get_OneXunJiState(i+1);
        sensor[i]= !Get_OneXunJiState(i+1);
        // 将传感器值左移到正确位置并添加到结果中
        allXunJi_value |= (sensorValue << (7-i));
    }
    
    return allXunJi_value;
}


 int Get_XunJi_WeightValue(void) 
{   
	static int last_valid_return = 0;
    allXunJi_value = Get_AllXunJi_Value();
	int result = 0;
    switch (allXunJi_value)
    {
//			case 255: return 6666;
//        // 0011 1111
//       case 63 :return  40 ;
//        // 1001 1111
//       case 159 :return 30 ;
//        // 1100 1111
//       case 207 :return 20 ; 
//       // 0111 1111
//       case 127 :return 40 ;
//       // 1011 1111
//        case 191 :return 30 ;
//       // 1101 1111
//       case 223 :return 20 ; 

//       //理想状态
//       //1110 0111
//       case 231 :return 0 ;
//         //1110 1111
//        case 239 :return 10 ;
//         //1111 0111
//        case 247 :return -10 ;

//        // 车偏右
//        //1111 0011
//       case 243:return -20;
//        // 1111 1001
//       case 249 :return -30;
//        // 1111 1100
//       case 252 :return -40;
//        //1111  1011
//       case 251:return -20;
//        // 1111 1101
//       case 253 :return -30;
//        // 1111 1110
//       case 254 :return -40;
//       default : return   0;
			 
			 
			 
		// 1111 0111
case 247: result =0;break;//-10

// 1111 1011
case 251: result =-20;break;

// 1111 1101
case 253: result =-30;break;

// 1111 1110
case 254: result =-40;break;


// 1111 0011
case 243: result =-20;break;

// 1111 1001
case 249: result =-30;break;

// 1111 1100
case 252: result =-40;break;

// 1111 0001
case 241: result =-30;break;

// 1111 1000
case 248: result =-40;break;

   // 1111 0000
case 240: result =-40;break;

//// 1110 0111
//case 231: return 0;


// 1110 1111
case 239: result =10;break;//10

// 1101 1111
case 223: result =20;break;

// 1011 1111
case 191: result =30;break;

// 0111 1111
case 127: result =40;break;


// 1100 1111
case 207: result =20;break;

// 1001 1111
case 159: result =30;break;

// 0011 1111
case 63: result =40;break;


// 1000 1111
case 143: result =30;break;

// 0001 1111
case 31: result =40;break;

 // 0000 1111
case 15: result =40;break;

 //1111 1111
case 255:  result = last_valid_return;break;	
default : result =0; break;
     }
		
		  if (allXunJi_value != 255)
		{
        last_valid_return = result;
    }
		return result;
}

void TI_1(float denominator, uint8_t i_min, uint8_t i_max) {
	
	//当灰度识别到两个黑线时候才开始判断
	if ( denominator >= 2&&denominator <=4) {  
								
						if ( abs(i_max - i_min) >= 2) {
					    buzzerflag=1;
							chose_state = 1;  //选择轨道为外圈
						}
						
						//当上一次识别到选择弯道，但是下一次识别到黑线的间距差小于2，此时标志位被置为，但是不清除
						else {
					
						chose_state = 0;
						}
					
						
				}
					else {
						chose_state = 0;
					}
}

void TI_2(float denominator, uint8_t i_min, uint8_t i_max) {
	
	//当灰度识别到两个黑线时候才开始判断
	        if ( denominator >= 6)
	        {
					jichu_speed=280;
					}
					else  if ( denominator >= 2) { 
								
						if ( abs(i_max - i_min) >= 2) {
					
							chose_state = 1;  //选择轨道为外圈
						}
						
						//当上一次识别到选择弯道，但是下一次识别到黑线的间距差小于2，此时标志位被置为，但是不清除
						else {
					
						chose_state = 0;
						}
					
						
				}
					else {
						chose_state = 0;
					}
}


void TI_3(float denominator, uint8_t i_min, uint8_t i_max) {
	
	//当灰度识别到两个黑线时候才开始判断
		if (denominator >=6)
	        {
          count_2=1;
						
					}					
	       else if ( denominator >= 2) { 
								
						if ( abs(i_max - i_min) >= 2) {
							buzzerflag=1;
							if(count_flag==0&&count_2==1)
							{
							count_flag=1;
							chose_state = 1;  //选择轨道为外圈	
							}
							else if(count_flag==1)
							{
							jichu_speed=460;
							chose_state = 2;  //选择轨道为内圈
							chaos_flag=0;//关超声波	
							count_flag=2;	
							LED_AllOn();	
							}
							else if(count_flag==2)
							{
							jichu_speed=280;	
							LED_AllOff();
							chaos_flag=1;
							chose_state =1; 	
							}
							
						}
						
						//当上一次识别到选择弯道，但是下一次识别到黑线的间距差小于2，此时标志位被置为，但是不清除
						else {
					
						chose_state = 0;
						}
					
						
				}
					else {
						chose_state = 0;
					}
}

//利用灰度传感来获得初步的循迹误差,其每次计算得权重就是偏差得角度值
void get_sensor_actual(void)
{
    float numerator = 0.0f;//权重值
    float denominator = 0.0f;//扫到黑线的灰度个数
	
	 uint8_t i_min = 7;
	 uint8_t i_max = 0;
    
Get_AllXunJi_Value();   
 	
    for(int i=0; i<8; i++) 
	{			
		if(sensor[i] == 1)
			{
					if (i <= i_min) {
					
						i_min = i;
					}
				
					if (i >= i_max) {
					
						i_max = i;
					}  
				denominator += 1.0f;//计次加一
				
			if (chose_TI == 1) {
				
				TI_1(denominator, i_min, i_max);
			}
			else if (chose_TI == 2) {
				
				TI_2(denominator, i_min, i_max);
			}
			else if (chose_TI == 3) {
				
				TI_3(denominator, i_min, i_max);
			}
				
		}
            
    }
  		
		if (chose_state == 1) //外圈
	{
			leftturn_speed=20;
      rightturn_speed=0;		
			if(denominator==1)
         {
					count_1++;
   if(count_1>=2)
		 {	
			 count_1=0;				 
				 chose_state =0;
				 leftturn_speed=0;
         rightturn_speed=0; 			 
		}
		 else {count_1=0;}
				 }
		}
		else if (chose_state == 2)//内圈 
		{
			leftturn_speed=-40;
      rightturn_speed=40;
				if(denominator==1)
         {
					 count_1++;
					 if(count_1>=2)
		   {
				 count_1=0;
				 chose_state =0;
				 leftturn_speed=0;
         rightturn_speed=0; 					 
				}
        else {count_1=0;}			 
				 }
		}
}



/*----------------------信号接收部分-------------------------*/


void LY_init(void) {
	
			NVIC_ClearPendingIRQ(LY_INST_INT_IRQN);  //上电时候首先清空该中断, 不能让使能中断之前的操作（数据）触发中断
    NVIC_EnableIRQ(LY_INST_INT_IRQN);  //开启该中断, 由于初始化里面已经开启了接收中断所以这里只需要开启CPU的处理中断请求就行

    DL_UART_Main_receiveData(LY_INST);  //防止中断初始化前标志位被错误置为导致中断后续无法触发	
	
}

void LY_INST_IRQHandler(void) 
{
	uint8_t rx_date = DL_UART_Main_receiveData(LY_INST);
	if (rx_date == 0x33) //停车
	{
				buzzerflag=1;
		    xunjiPidFlag=0;
		    Motor_SetSpeed(0,0);
        chaos_flag=0;
	}
  else if	(rx_date == 0x55)////第一题
	{
	jichu_speed=275;	
	buzzerflag=1;
	xunjiPidFlag=1;
	chose_TI =1;
	chaos_flag=1;
	}
	  else if	(rx_date == 0x56)////第2题
	{
	jichu_speed=460;		
	buzzerflag=1;
	xunjiPidFlag=1;
	chose_TI =2;
	chaos_flag=1;
	}
		  else if	(rx_date == 0x57)////第3题
	{		
	buzzerflag=1;
	xunjiPidFlag=1;
	chose_TI =3;
	chaos_flag=1;
	}



	
}


