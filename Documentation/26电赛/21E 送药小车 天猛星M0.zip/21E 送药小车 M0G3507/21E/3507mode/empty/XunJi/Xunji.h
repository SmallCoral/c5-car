#ifndef __XUNJI_H
#define __XUNJI_H

#include "ti_msp_dl_config.h"


typedef struct {
	float Actual;
	float Actual1;
	
	float Feedforwad;
	
	float Target;
	float Last_Target;
	float Out;
	
	float Kp;
	float Ki;
	float Kd;
	float Kf;
	
	float Error0;
	float Error1;
	float ErrorInt;
	
	float ErrorIntMax;
	float ErrorIntMin;
	
	float OutMax;
	float OutMin;
}PID_XunJi;


extern PID_XunJi gyro_inter;
extern PID_XunJi gray_out;

extern uint8_t motor_state;

extern int16_t L_P, R_P;
extern int16_t AveP, DifP;


void Car_setspeed(int16_t Speed);

void gyro_control_inter(void);

void gray_control_out(void) ;


void PID_Xunji_Updata_out(PID_XunJi* p);

void PID_Xunji_Updata_inter(PID_XunJi* p);

float get_sensor_actual(void);

#endif
