#ifndef __MENU_H__
#define __MENU_H__
#include "headfile.h"
extern char text[20];

extern uint32_t mytime_ms;

int main_menu(void); 
int menu1(void);
int menu2(void);
int menu3(void);
int menu4(void);

extern uint8_t queston_num;

#endif