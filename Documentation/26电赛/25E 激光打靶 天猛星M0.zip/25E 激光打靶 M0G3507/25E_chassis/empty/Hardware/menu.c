#include <menu.h>
#include <bsp_system.h>


/*

对于JY901车身向右转动时候，角度值减减；  当车身向左转动时，角度值加加


*/


uint8_t Target_quan = 1;  //初始状态小车目标走一圈


int16_t test = 1;
float Z_angel;


char show_buffer[20];


int8_t func_index = 0;  

typedef struct {
	
	int8_t current_index;
	int8_t Up_index;
	int8_t Domn_index;
	 void (*current_operation)(void); 
	
}menu_tab;

void (*current_operation_index)(void); 


menu_tab menu[6] = {
	
	{0, 2, 1, (*Boot_animation)},
	{1, 0, 2, (*Homepage_1)},
	{2, 1, 0, (*Homepage_2)},

};


void menu_operation(void) {
	
	uint8_t Key_Num = key_proc();
	
	if (Key_Num == 1) {
		func_index = menu[func_index].Up_index;
		OLED_Clear();	
	}
	

	
	if (Key_Num == 2) {
		func_index = menu[func_index].Domn_index;
		OLED_Clear();  		
	}
	


//在第一菜单界面下， 按下按键3,4时候才会 开车/停车	
	if (menu[func_index].current_index == 0) {
		
			if (Key_Num == 3) {
		
					motor_state = 1;
			}		
			
				if (Key_Num == 4) {
		
					motor_state = 0;
				
			}
			
	}
	

	
	


	
	//第2菜单
	if (menu[func_index].current_index == 1) {
		
		if (Key_Num == 3) {
			
			Target_quan++;
			if (Target_quan >= 5)  Target_quan = 5;
			
		}
		
		if (Key_Num == 4) {
			
			Target_quan--;
			if (Target_quan <= 0) Target_quan = 0;
			
		}
		
	}
	//第3菜单
		if (menu[func_index].current_index == 2) {
		
					if (Key_Num == 3) {
		}
		
		if (Key_Num == 4) {
			

		}
			
			

		
		
	}
	
	
	current_operation_index = menu[func_index].current_operation;
	
	if (current_operation_index != NULL) {
		
		(*current_operation_index)();	
	}
	
	
}


/*----------------菜单界面-----------------*/

void Boot_animation(void) {
	
	sprintf(show_buffer, "JY_A: %.1f", JY_Angle);
	OLED_ShowString(1, 1, show_buffer);
	
	
	sprintf(show_buffer, "M_S: %d", motor_state);  //小车状态
	OLED_ShowString(2, 1, show_buffer);

	
	sprintf(show_buffer, "R_S: %d", R_Speed);
	OLED_ShowString(3, 1, show_buffer);
	

	sprintf(show_buffer, "IT: %d", IT_Flag_1);
	OLED_ShowString(4, 1, show_buffer);

}

void Homepage_1(void) {
	


	sprintf(show_buffer, "q_count: %d ", quan_count);
	OLED_ShowString(1, 1, show_buffer);

	sprintf(show_buffer, "R_S: %d ", Run_State);  //黑线状态（直行）与白线状态（转向）
	OLED_ShowString(2, 1, show_buffer);
	
	sprintf(show_buffer, "T_Q: %d", Target_quan);   //目标圈数
	OLED_ShowString(3, 1, show_buffer);
	
}

void Homepage_2(void) {
	
	sprintf(show_buffer, "kp:%.2f ",XunJi_PID.Kp);
	OLED_ShowString(1, 1, show_buffer);
	sprintf(show_buffer, "kd:%.2f ",XunJi_PID.Kd);
	OLED_ShowString(2, 1, show_buffer);
	

		sprintf(show_buffer, "turnkp:%.2f ",Turn_PID.Kp);
	OLED_ShowString(3, 1, show_buffer);
	sprintf(show_buffer, "turnkd:%.2f ",Turn_PID.Kd);
	OLED_ShowString(4, 1, show_buffer);
}



