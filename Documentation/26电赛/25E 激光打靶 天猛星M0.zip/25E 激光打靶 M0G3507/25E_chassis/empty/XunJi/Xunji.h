#ifndef __XUNJI_H
#define __XUNJI_H

#include "ti_msp_dl_config.h"


typedef struct {
	float Actual;
	float Actual1;
	
	float Target;
	float Out;
	
	float FeedForward;
	float Last_Target;
	float Kf;
	
	float Kp;
	float Ki;
	float Kd;
	
	float Error0;
	float Error1;
	float ErrorInt;
	
	float ErrorIntMax;
	float ErrorIntMin;
	
	float OutMax;
	float OutMin;
}PID_XunJi;


extern int16_t L_Speed, R_Speed;

extern uint8_t motor_state;

extern int Run_State;  
extern int quan_count; 
extern PID_XunJi XunJi_PID;
extern PID_XunJi Turn_PID;
void Car_setspeed(int16_t Speed);

float get_sensor_actual(void);

void PID_Xunji(void);
void Turn_Angel(void);


void PID_Xunji_Updata(PID_XunJi* p);



#endif
