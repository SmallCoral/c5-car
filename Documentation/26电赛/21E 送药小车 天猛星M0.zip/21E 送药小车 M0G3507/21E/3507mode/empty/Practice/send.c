#include <send.h>
#include <bsp_system.h>

//uint8_t car_state = 0;   //0为送药状态， 1为返回状态

uint8_t last_Turn = 0;  //记录上一次的转弯数值
uint8_t now_Turn = 0;

// 声明为局部静态，把延时代码和内聚在一起，不污染文件作用域
uint16_t send_delay_begain = 0;
uint8_t  send_delay_use = 1;   //为了防止不断地重复进入

uint16_t car_turn_delay_begain = 0;
uint8_t  car_turn_delay_use = 1;

uint16_t car_gray_delay_begain = 0;
uint8_t  car_gray_delay_use = 1;


uint8_t room_state = 0;   //0表示初始状态此时目标为近端药房， 1为终端药房， 2为远端药房
uint8_t gray_count_begain = 0;


float Angle_Bias = 0.0f;  //当小车转弯进入药房时候，会回归到原本的循迹状态， 此时需要给PID目标值一个偏差置

uint32_t medicine_in = 0;   //0表示未持有药物， 1表示药物已经装载
Pharmacy room_chose = NONE_ROOM;

Position CAM_COMMAD = NONE_DATE;    //初始时候小车巡直线
Pattern XUN_COMMAD = FETCH_ROOM;   //初始时候小车巡线模式为巡线状态

//回家转弯参数
static uint8_t near_turn_num = 1;  //对于近端与中断药房只需要转弯一次
static uint8_t far_turn_num = 2;



//用于判断是否填装药品
void load_medicine(void) {
	
	
			//传感器上点的一瞬间肯定是读取到了低电平, 标志位一定会被置为
	//当药品在小车上面， 且小车处于等待药品状态时候， 进入送药状态
	//由于该函数放在主循环里面，为了防止其破坏破别状态， 给其设置一个单独的标志位	
    // 送药延时：条件达成时开始计时，到时启动电机
		if(  DL_GPIO_readPins(Read_PORT, Read_PIN_1_PIN) == 0)  {
		
		
			medicine_in = 0;
	
		//送药延时			
      send_delay_begain = 1;   // 开始计时


		}
		else {
				
			//当循迹状态处于返回状态时候
			if (XUN_COMMAD == WAIT_COME_BACK && motor_state == 0) {
				
				motor_state = 4;
			}
				
				medicine_in = 1;
				send_delay_begain = 0;   // 重新置为，为下一次送药做准备
			//send_delay_use = 1;   // 不需要重新置为，只需要进来一次就行
		}
	
		/*
		注意：对于计数这一部分， 我的药品一旦被拿走就要清零
		但是， 对于灰度停止， 与灰度转弯， 不能一没有识别到指定数目的黑线就清零， 不然无法继续下去
		*/

	
}


//用于判断小车是否识别到了指示牌， 并获取指示牌信息 
void Send_Room(void) {
	
	
	
//只有在送药状态才有视觉
//防止回家的时候识别到标识导致状态切换， 在回家状态选择关闭视觉
	if (XUN_COMMAD != BEGAIN_COME_BACK) {
		
				if (CAM_COMMAD == WAIT_TURN_LEFT || CAM_COMMAD == WAIT_TURN_RIGHT) {
		
			XUN_COMMAD = WAIT_GRAY_STOP;   //识别到了指示牌，开始等待识别到一条转弯线 v
		}
	
		//记录上一次转向的数值
		if (room_state == 2 && CAM_COMMAD == WAIT_TURN_LEFT) {
			
			last_Turn = 10;
		}
		else if (room_state == 2 && CAM_COMMAD == WAIT_TURN_RIGHT) {
			
			last_Turn = 20;
		}

		//记录本次转向的数值
		 if (room_state == 3 && CAM_COMMAD == WAIT_TURN_LEFT) {
			
			now_Turn = 10;
		}
		else if (room_state == 3 && CAM_COMMAD == WAIT_TURN_RIGHT) {
			
			now_Turn = 20;
		}
		else if (room_state < 2 && CAM_COMMAD == WAIT_TURN_LEFT){
			
			now_Turn = 1;
		}
		else if (room_state < 2 && CAM_COMMAD == WAIT_TURN_RIGHT) {
			
			now_Turn = 2;
		}
		
	}
		


}


//由于对远端
void distance_room( float demonitor) {
	
	//只有在送药时候才有该过程
	if (medicine_in == 0) {
		
		if (demonitor >= 6.0f) {
			
			gray_count_begain = 1;
		}
			
	}
	
	
}






/*-------------直角转弯与自身旋转180°部分--------------*/

void Gray_Stop(float denominator) {

	
	
	//等待停车转弯，进入药房
	if (XUN_COMMAD == WAIT_GRAY_STOP ) {
		
		if (denominator >= 6.0f) {
			
			car_gray_delay_begain = 1;   // 开始计时
			
		}
}
}

/*--------------转直角弯道PID------------*/

PID_XunJi confidence = {
	
	.Kp = 6.0f,
	.Ki = 0.0f,
	.Kd = 5.0f,

	.ErrorIntMax = 400.0f,
	.ErrorIntMin = -400.0f,
	
	. OutMax = 190.0f,
	.OutMin = -190.0f,
	
};



//当motor_state = 2时候， 小车进入拐弯状态， 需要调用这个函数来进行拐弯
//这个地方是可以优化的， 不需要写死，可以用PID来调节
void Car_Turn(void) {

	int16_t left_speed = 0;
	int16_t right_speed = 0;

	//对于近端和中端病房,需要左转 
	if ( now_Turn == 1) {
		
		confidence.Target = 90.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = 0;
		right_speed = (int16_t)confidence.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);

	}
	
	//对于近端和中端病房,需要右转 
	else if (now_Turn == 2) {
		
		confidence.Target = -90.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = -(int16_t)confidence.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);

	}
	
	//对与远端药房，需要转两次
	//已经完成灰线停车， 需要开始转弯
	//第一次摄像头识别到需要左转
	else if (room_state == 3 && last_Turn == 10) {
		
		confidence.Target = 90.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = 0;
		right_speed = (int16_t)confidence.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
		
	}
	else if (room_state == 3 && last_Turn == 20) {
		
		confidence.Target = -90.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = -(int16_t)confidence.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	
	//已经完成灰线停车， 开始转弯
	//第二次转弯需要左转, 第一次为左转
	else if (room_state == 4 && now_Turn == 10 && last_Turn == 10) {
		
		confidence.Target = 180.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = 0;
		right_speed = (int16_t)confidence.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
		
	}
	
		//已经完成灰线停车， 开始转弯
	//第二次转弯 需要左转, 第一次为右转
	else if (room_state == 4 && now_Turn == 10 && last_Turn == 20) {
		
		confidence.Target = 0.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = 0;
		right_speed = (int16_t)confidence.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
		
	}
	
			//已经完成灰线停车， 开始转弯
	//第二次转弯 需要右转, 第一次为右转
	else if (room_state == 4 && now_Turn == 20 && last_Turn == 20) {
		
		confidence.Target = -180.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = -(int16_t)confidence.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);

	}
	
				//已经完成灰线停车， 开始转弯
	//第二次转弯 需要右转, 第一次为左转
	else if (room_state == 4 && now_Turn == 20 && last_Turn == 10) {
		
		confidence.Target = 0.0f;
		confidence.Actual = JY_Angel;
		
		PID_Spin(&confidence);
		
		left_speed = -(int16_t)confidence.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
		



//写死：小车转直角弯道
		car_turn_delay_begain = 1;   // 开始计时
		car_turn_delay_use = 1;   // 开始计时, 每次进入motor_state = 2时候， 都会重新置为1， 以便于下一次转弯
		
}


/*--------------------小车左右摆动参数部分-----------------*/


PID_XunJi spin = {
	
	.Kp = 13.0f,
	.Ki = 0.0f,
	.Kd = 5.0f,

	.ErrorIntMax = 400.0f,
	.ErrorIntMin = -400.0f,
	
	.OutMax = 90.0f,
	.OutMin = -90.0f,
	
};


//当motor_state == 3时其处理函数
void swing_vision(void) {
	
	static uint8_t stop = 0;  //进入时先停止
	static uint8_t stop_tim = 0;
	
	static uint8_t Turn = 0;   //初始状态左转
	static uint16_t Turn_Tim = 0;
	
	static int16_t R_Speed = 0;
	static int16_t L_Speed = 0;
	
	static int16_t keep_balcace_tim = 0;
	
	
	//目的是到达后先停止
	if (stop == 0) {
		
		stop_tim++;
		if (stop_tim >= 50) {
			
			stop_tim = 0;
			stop = 1;
			Motor_Set_PWM(1, 0);  //右轮
			Motor_Set_PWM(2, 0);  //左轮
		}
	}
	else  {
		
		if (CAM_COMMAD == WAIT_TURN_LEFT || CAM_COMMAD == WAIT_TURN_RIGHT) {
			
			spin.Target = 0.0f;
			spin.Actual = JY_Angel;
			PID_Spin(&spin);
		
			R_Speed = (int16_t)spin.Out;
			L_Speed = -(int16_t)spin.Out;
			
			if (fabs(spin.Target - JY_Angel) <= 4.0f) {
				
				keep_balcace_tim++;
				if (keep_balcace_tim >= 100) {
					
					keep_balcace_tim = 0;
					motor_state = 1;
				}
				
				
			}
			else {
				
				keep_balcace_tim = 0;
			}
			
		}
		else {
			
				Turn_Tim++;
		if (Turn_Tim >= 350) {
			
			Turn_Tim = 0;
			Turn = !Turn;
		}
		
		if (Turn == 0) {
			
			spin.Target = 25.0f;  //左转
			spin.Actual = JY_Angel;
			PID_Spin(&spin);
		
			R_Speed = (int16_t)spin.Out;
			L_Speed = -(int16_t)spin.Out;
		}
		else if (Turn == 1){
			
			spin.Target = -30.0f;
			spin.Actual = JY_Angel;
			PID_Spin(&spin);
		
			R_Speed = (int16_t)spin.Out;
			L_Speed = -(int16_t)spin.Out;
		}
			
			
		}
		
			
			Motor_Set_PWM(1, R_Speed);  //右轮
			Motor_Set_PWM(2, L_Speed);  //左轮
		
		
		
	}
	
}



void PID_Spin(PID_XunJi* p) {
	
	p->Error1 = p->Error0;
	p->Error0 = p->Target - p->Actual;
	
	if (fabs(p->Ki) > 0.001) {
		
		p->ErrorInt += p->Error0;
	}
	else { p->ErrorInt = 0;}
	

	
	p->Out = p->Kp * p->Error0 
					+ p->Ki * p->ErrorInt 
					//+ p->Kd * (p->Error0 - p->Error1);
					-p->Kd * (p->Actual - p->Actual1);
	
	if (p->Out > p->OutMax) p->Out = p->OutMax;
	if (p->Out < p->OutMin) p->Out = p->OutMin;
	
	p->Actual1 = p->Actual;
}



/*-------------------返回逻辑-------------------*/

//到达药房停车
void arrive_stop(float demonitor, float last_demonitor, uint8_t i_max, uint8_t i_min) {
	
	static uint8_t guard_cover = 0;
	
	//当小车转弯完成，并且摄像头没有识别到需要转弯的轨道时候
	//注意重复进入
	if (CAM_COMMAD == COMPLET_TURN && room_state == 4 && guard_cover == 0) { 
		
		 if ((last_demonitor != 0.0f && demonitor == 0.0f) || (abs(i_max - i_min) >= 3)) {
			 
			 motor_state = 0;  //小车识别到药房进入状态0，准备转向
			 guard_cover = 1;
			 XUN_COMMAD = WAIT_COME_BACK;   //小车变为返回状态， 此时关闭视觉
			 
		 }
	}
	else if (CAM_COMMAD == COMPLET_TURN &&  room_state < 3 && guard_cover == 0) {
		
	 if ((last_demonitor != 0.0f && demonitor == 0.0f) || (abs(i_max - i_min) >= 3)) {
			 
			 motor_state = 0;  //小车识别到药房进入状态0，准备转向
			 guard_cover = 1;
			 XUN_COMMAD = WAIT_COME_BACK;   //小车变为返回状态
		 }
	}
		
	
}





PID_XunJi Turn_Down = {
	
	.Kp = 5.0f,
	.Ki = 0.0f,
	.Kd = 5.0f,

	.OutMax = 210.0f,
	.OutMin = -210.0f,
	
};


//状态4,小车转向
void car_Trun_Down(void) {
	
	static uint16_t Turn_Down_tim = 0;
	int16_t R_Speed = 0;
	int16_t L_Speed = 0;
	
	Turn_Down_tim++;
	
	if (Turn_Down_tim >= 300) {
		
		Turn_Down_tim = 0;
		XUN_COMMAD = BEGAIN_COME_BACK;  //小车转向完成， 开始正式回家
		
		motor_state = 5 ;   //小车转向完成， 切换到状态5, 开始返回(不会重复进入， 置为为状态4）
		
	}
	
	if (last_Turn == 10 && now_Turn == 10) {
		
		Turn_Down.Target = 0.0f;
	}
	else if (last_Turn == 10 && now_Turn == 20) {
		
		Turn_Down.Target = 180.0f;
	}
	else if (last_Turn == 20 && now_Turn == 10) {
		
		Turn_Down.Target = 180.0f;
	}
	else if (last_Turn == 20 && now_Turn == 20) {
		
		Turn_Down.Target = 0.0f;
	}
	else if (now_Turn == 1) {
		
		Turn_Down.Target = -90.0f;
	}
	else if (now_Turn == 2) {
		
		Turn_Down.Target = 90.0f;
	}
		
	Turn_Down.Actual = JY_Angel;
	
	PID_Spin(&Turn_Down);
	
	R_Speed = (int16_t)Turn_Down.Out;
	L_Speed = -(int16_t)Turn_Down.Out;
	
	Motor_Set_PWM(1, R_Speed);
	Motor_Set_PWM(2, L_Speed);
	
}





/*--------------回家PID------------*/
PID_XunJi come_back = {
	
	.Kp = 20.0f,
	.Ki = 0.0f,
	.Kd = 5.0f,

	.OutMax = 210.0f,
	.OutMin = -210.0f,
	
};

//带你们回来， 状态5，准备会家
//打算写死， 不再弄陀螺仪了， 角度弄得太麻烦了，懒一次
void car_come_back(void) {
	
	static int16_t B_L_Speed = 0;
	static int16_t B_R_Speed = 0;
	
	int16_t B_Bias = 0;
	
	come_back.Target = 0.0f;
	come_back.Actual = XunJi_Value;
	
	PID_Spin(&come_back);
	
	B_Bias = (int16_t)come_back.Out;
	
	B_L_Speed = AveP + B_Bias;
	B_R_Speed = AveP - B_Bias;
	
	Motor_Set_PWM(1, B_R_Speed);
	Motor_Set_PWM(2, B_L_Speed);
}


//该函数只有在XUN_COMMAD == BEGAIN_COME_BACK时候才有此判断函数
void come_back_pattern_change(float demonitor) {
	
	static uint8_t near_begain_count = 0;
	static uint8_t far_begain_count = 0;
	
	static uint16_t near_count = 0;
	static uint16_t far_count = 0;
	
	//对于近端与药房
	if (demonitor >= 4.0f && room_state < 4 && near_turn_num != 0) {
		
		motor_state = 6; //切换到状态6
		near_begain_count = 1;
		DL_GPIO_clearPins(LED_PIN_0_PORT, LED_PIN_0_PIN);
		
	}
	
	//对于远端药房
	//注意防止同一时间重复进入!!!
	else if (demonitor >= 4.0f && room_state >= 4 &&far_turn_num != 0) {
		
		motor_state = 6;
		far_begain_count = 1;
	}
	
	
	
	if (near_begain_count == 1) {
		
		near_count++;
		if (near_count >= 300) {
			
			near_begain_count = 0;
			near_count = 0;
			near_turn_num--;  //回家需要的转弯次数变为0
			motor_state = 5;
		}
	}
	
	
		if (far_begain_count == 1) {
		
		far_count++;
		if (far_count >= 200) {
			
			far_begain_count = 0;
			far_count = 0;
			far_turn_num--;
			motor_state = 5;
		}
	}
	
	
	
}



PID_XunJi turn_come_back = {
	
	.Kp = 6.0f,
	.Ki = 0.0f,
	.Kd = 5.0f,

	.OutMax = 210.0f,
	.OutMin = -210.0f,
	
};

//最后的模式。。。。。
//这里注意， 需要知道小车完成180°转向后的实际角度， 才能写返回时候的目标值。。。
//上一句所需要的这个角度就是我们在转向时候设置的目标角度

//可以优化的地方：左轮和右轮不一样， 有较大区别
//可以设置一个角度的误差值，来置标志位
void last_state(void) {
	
	int16_t left_speed = 0;
	int16_t right_speed = 0;
	
	//此时实际角度0°, 右拐，左轮加速
	if (last_Turn == 10 && now_Turn == 10 && far_turn_num == 2) {
		
		turn_come_back.Target = -90.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = -(int16_t)turn_come_back.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	//此时实际角度-90°, 右拐，左轮加速
	else if (last_Turn == 10 && now_Turn == 10 && far_turn_num == 1) {
		
		turn_come_back.Target = -180.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = -(int16_t)turn_come_back.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	
	
	//此时实际角度180°, 左拐， 右轮加速
	else if (last_Turn == 10 && now_Turn == 20 && far_turn_num == 2) {
		
		turn_come_back.Target = 270.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = 0;
		right_speed = (int16_t)turn_come_back.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	//此时实际角度270°, 右拐， 左轮加速
	else if (last_Turn == 10 && now_Turn == 20 && far_turn_num == 1) {
		
		turn_come_back.Target = 180.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = -(int16_t)turn_come_back.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	
	
	//此时实际角度180°, 右拐， 左轮加速
	else if (last_Turn == 20 && now_Turn == 10 && far_turn_num == 2) {
		
		turn_come_back.Target = 90.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = -(int16_t)turn_come_back.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
		
	}
	//此时实际角度90°, 左拐， 右轮加速
		else if (last_Turn == 20 && now_Turn == 10 && far_turn_num == 1) {
		
		turn_come_back.Target = 180.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = 0;
		right_speed = (int16_t)turn_come_back.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	
	
	//此时实际角度0°, 左拐， 右轮加速
	else if (last_Turn == 20 && now_Turn == 20 && far_turn_num == 2) {
		
		turn_come_back.Target = 90.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = 0;
		right_speed = (int16_t)turn_come_back.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	//此时实际角度90°, 左拐， 右轮加速
		else if (last_Turn == 20 && now_Turn == 20 && far_turn_num == 1) {
		
		turn_come_back.Target = 180.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = 0;
		right_speed = (int16_t)turn_come_back.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
		
	
	//此时实际角度-90°, 右拐， 左轮加速
	else if ((now_Turn == 1 || now_Turn == 10) && (near_turn_num == 1)) {
		
		turn_come_back.Target = -180.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = -(int16_t)turn_come_back.Out;
		right_speed = 0;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	
	//此时实际角度90°, 左拐， 右轮加速
	else if ((now_Turn == 2 || now_Turn == 20) && (near_turn_num == 1)) {
		
		turn_come_back.Target = 180.0f;
		turn_come_back.Actual = JY_Angel;
		
		PID_Spin(&turn_come_back);
		
		left_speed = 40;
		right_speed = (int16_t)turn_come_back.Out;

		Motor_Set_PWM(1, right_speed);
		Motor_Set_PWM(2, left_speed);
	}
	
}


