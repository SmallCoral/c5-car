#include "headfile.h"

void Motor_SetSpeed(int left_speed, int right_speed) // 范围在-1000 - 1000
{
	// 限制速度在有效范围内
	if (left_speed > 1000)
	{
		left_speed = 1000;
	}
	else if (left_speed < -1000)
	{
		left_speed = -1000;
	}

	// 左轮
	if (left_speed >= 0)
	{
		DL_GPIO_setPins(motor_PORT_motor_BIN1_PORT_PORT, motor_PORT_motor_BIN1_PORT_PIN);
		DL_GPIO_clearPins(motor_PORT_motor_BIN2_PORT_PORT, motor_PORT_motor_BIN2_PORT_PIN);
		// 设定左轮占空比
		DL_TimerG_setCaptureCompareValue(PWM_0_INST, left_speed, DL_TIMER_CC_1_INDEX); // 设置ccr的值
	}
	else
	{
		DL_GPIO_clearPins(motor_PORT_motor_BIN1_PORT_PORT, motor_PORT_motor_BIN1_PORT_PIN);
		DL_GPIO_setPins(motor_PORT_motor_BIN2_PORT_PORT, motor_PORT_motor_BIN2_PORT_PIN);

		DL_TimerG_setCaptureCompareValue(PWM_0_INST, -left_speed, DL_TIMER_CC_1_INDEX); // 设置ccr的值
	}

	// 右轮

	if (right_speed > 1000)
	{
		right_speed = 1000;
	}
	else if (right_speed < -1000)
	{
		right_speed = -1000;
	}
	if (right_speed >= 0)
	{
		DL_GPIO_setPins(motor_PORT_motor_AIN1_PORT_PORT, motor_PORT_motor_AIN2_PORT_PIN);
		DL_GPIO_clearPins(motor_PORT_motor_AIN2_PORT_PORT, motor_PORT_motor_AIN1_PORT_PIN);

		// 设定右轮占空比
		DL_TimerG_setCaptureCompareValue(PWM_0_INST, right_speed, DL_TIMER_CC_0_INDEX); // 设置ccr的值
	}
	else
	{
				DL_GPIO_clearPins(motor_PORT_motor_AIN1_PORT_PORT, motor_PORT_motor_AIN2_PORT_PIN);
		DL_GPIO_setPins(motor_PORT_motor_AIN2_PORT_PORT, motor_PORT_motor_AIN1_PORT_PIN);

		// 设定右轮占空比
		DL_TimerG_setCaptureCompareValue(PWM_0_INST, -right_speed, DL_TIMER_CC_0_INDEX); // 设置ccr的值
	}
}


float real_speed(uint8_t motor_choose)
{
float speed=0.0;

if(motor_choose==1)
{	
	speed=(float)encoder_l_count/encoder_onequan*PI*MOTOR_WHEEL_D*100;//单位mm/s
  encoder_l_count=0;
}
else if(motor_choose==2)
{	
	speed=(float)encoder_r_count/encoder_onequan*PI*MOTOR_WHEEL_D*100;//单位mm/s
  encoder_r_count=0;
}
	return speed;
}

float real_distance(void)
{                                                                                                                                 
	float encoder_left1=(float)encoder_left;
	float encoder_right1=(float)encoder_right;
	float left_distance,right_distance;
	left_distance=encoder_left1/encoder_onequan*PI*MOTOR_WHEEL_D;
	right_distance=encoder_right1/encoder_onequan*PI*MOTOR_WHEEL_D;
	return (left_distance+right_distance)/2.0f;
}	
