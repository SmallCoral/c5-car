#ifndef __JY_H
#define __JY_H

#include "ti_msp_dl_config.h"

extern float JY_Angel;

void JY_Initt(void);

void JY60_data_proc(void);

float JY_angle_error(void);


#endif 

