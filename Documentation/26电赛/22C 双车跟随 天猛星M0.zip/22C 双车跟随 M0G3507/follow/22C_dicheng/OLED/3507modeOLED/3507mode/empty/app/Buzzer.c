#include "headfile.h"

uint8_t buzzerflag = 0 ;

void buzzer_On(void)
{
  DL_GPIO_setPins(buzzer_PORT, buzzer_PIN_1_PIN);
}

void buzzer_Off(void)
{
	DL_GPIO_clearPins(buzzer_PORT, buzzer_PIN_1_PIN);
}

//void buzzer_500ms() 
//{
//	if(buzzerState == 0)
//	{
//		buzzer_On();
//		buzzerState = 1;
//	}
//}