#include <menu.h>
#include <bsp_system.h>


/*

对于JY901车身向右转动时候，角度值减减；  当车身向左转动时，角度值加加


*/



int16_t test = 1;
float Z_angel;

uint8_t chose_TI = 1;  //选择所行驶的题目


char show_buffer[20];


int8_t func_index = 0;  

typedef struct {
	
	int8_t current_index;
	int8_t Up_index;
	int8_t Domn_index;
	 void (*current_operation)(void); 
	
}menu_tab;

void (*current_operation_index)(void); 


menu_tab menu[6] = {
	
	{0, 2, 1, (*Boot_animation)},
	{1, 0, 2, (*Homepage_1)},
	{2, 1, 0, (*Homepage_2)},

};


void menu_operation(void) {
	
	uint8_t Key_Num = key_proc();
	
	if (Key_Num == 1) {
		func_index = menu[func_index].Up_index;
		OLED_Clear();	
	}
	

	
	if (Key_Num == 2) {
		func_index = menu[func_index].Domn_index;
		OLED_Clear();  		
	}
	


//在第一菜单界面下， 按下按键3时候才会 开车/停车	
	if (menu[func_index].current_index == 0) {
		
			if (Key_Num == 3) {
		
					
			}		
			
				if (Key_Num == 4) {
		
					
				
			}
			
	}
	

	
	


	
	
	if (menu[func_index].current_index == 1) {
		
		if (Key_Num == 3) {
			
			
		}
		
		if (Key_Num == 4) {
			
			
		}
		
	}
	
	
	current_operation_index = menu[func_index].current_operation;
	
	if (current_operation_index != NULL) {
		
		(*current_operation_index)();	
	}
	
	
}


/*----------------菜单界面-----------------*/

void Boot_animation(void) {
	

	
	sprintf(show_buffer, "Angle: %.1f   ", JY_Angel);
	OLED_ShowString(1, 1, show_buffer);
	
//			sprintf(show_buffer, "R_S: %d   ", room_state);
//	OLED_ShowString(1, 1, show_buffer);
	
	
//	

	
			sprintf(show_buffer, "R_S: %d   ", room_state);
	OLED_ShowString(2, 1, show_buffer);
	
//		sprintf(show_buffer, "X_C: %d   ", XUN_COMMAD);
//	OLED_ShowString(2, 1, show_buffer);
//	
	sprintf(show_buffer, "Bias: %.1f   ", Angle_Bias);
	OLED_ShowString(3, 1, show_buffer);
	
	
		sprintf(show_buffer, "M_S: %d   ", motor_state);
	OLED_ShowString(4, 1, show_buffer);
	
//		sprintf(show_buffer, "Bia: %d", DifP);
//	OLED_ShowString(2, 1, show_buffer);
//	
//	
//		sprintf(show_buffer, "L_S: %d   ", L_P);
//	OLED_ShowString(3, 1, show_buffer);
	
//		sprintf(show_buffer, "R_S: %d   ", R_P);
//	OLED_ShowString(4, 1, show_buffer);
//	


}

void Homepage_1(void) {
	


	sprintf(show_buffer, "T_D: %.1f ", Turn_Down.Target);
		OLED_ShowString(1, 1, show_buffer);
	
	sprintf(show_buffer, "C_B: %.1f ", turn_come_back.Target);
		OLED_ShowString(2, 1, show_buffer);
	
	sprintf(show_buffer, "TI: %d   ", IT_Flag_1);
	OLED_ShowString(3 , 1, show_buffer);
	

}

void Homepage_2(void) {
	
	sprintf(show_buffer, "HH");
	OLED_ShowString(1, 1, show_buffer);

}



