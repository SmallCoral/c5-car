#ifndef __MOTOR_H
#define __MOTOR_H

#include "ti_msp_dl_config.h"


void Motor_Init(void);

void Motor_Set_PWM(int n, int16_t PWM);

#endif