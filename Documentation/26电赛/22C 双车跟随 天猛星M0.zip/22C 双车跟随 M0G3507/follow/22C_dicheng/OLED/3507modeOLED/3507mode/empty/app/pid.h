#ifndef __PID_H
#define __PID_H
#include "headfile.h"

typedef struct PID
{
	float kp;
    float ki ; // 积分
    float kd ; // 微分
	  float Kff;//前馈系数
    float errorNew ;
    float errorLast ;
    float errorInt ; // 误差积分
    int errorIntMax ; // 积分限幅
    float target ; // 目标值
    float actual ; // 实际值
	  float targetlast ; // 上次目标值
    float out; // 调控力度 
    int outMax; // 调控力度的范围

	uint32_t TickCount; // 计数
    uint8_t flag; // 0表示循迹pid 1表示角度pid
}pid; 

extern int jichu_speed;
//void PID_Tick(pid* pid);
void PID_Cal(pid* pid);
void Task_10ms(void);
extern pid xunjiPid;
extern uint8_t xunjiPidFlag;
extern pid chaosPid;
#endif