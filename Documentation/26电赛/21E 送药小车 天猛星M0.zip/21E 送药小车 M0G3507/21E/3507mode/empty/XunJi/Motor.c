#include "Motor.h"
#include "bsp_system.h"




void Motor_Init(void) {
	
	DL_GPIO_clearPins(Motor_AIN1_PORT, Motor_AIN1_PIN);
	DL_GPIO_clearPins(Motor_AIN2_PORT, Motor_AIN2_PIN);
	DL_GPIO_clearPins(Motor_BIN1_PORT, Motor_BIN1_PIN);
	DL_GPIO_clearPins(Motor_BIN2_PORT, Motor_BIN2_PIN);
	
	DL_TimerG_setCaptureCompareValue(PWM_INST, 0, DL_TIMER_CC_0_INDEX);  //设置定时器占空比
	DL_TimerG_setCaptureCompareValue(PWM_INST, 0, DL_TIMER_CC_1_INDEX);    //可以在初始化文件中找到
	
	DL_Timer_startCounter(PWM_INST);
}


// 1， 为右轮 AIN
//2, 为左轮  BIN
void Motor_Set_PWM(int n, int16_t PWM) {
	
	int32_t L_PWM = 0;
	int32_t R_PWM = 0;
	
	if (n == 1) {
	
	if (PWM >= 0) {
		
		DL_GPIO_clearPins(Motor_AIN1_PORT, Motor_AIN1_PIN);
		DL_GPIO_setPins(Motor_AIN2_PORT, Motor_AIN2_PIN);
	}
	else{
		
		DL_GPIO_setPins(Motor_AIN1_PORT, Motor_AIN1_PIN);
		DL_GPIO_clearPins(Motor_AIN2_PORT, Motor_AIN2_PIN);
	}
	
	 L_PWM = abs(PWM);  //注意再用abs()的时候不要将需要绝对值化的数据定义为无符号类型
	
	DL_TimerG_setCaptureCompareValue(PWM_INST, L_PWM, DL_TIMER_CC_0_INDEX);
	
}
	else if (n == 2) {
	
	if (PWM >= 0) {
		
		DL_GPIO_setPins(Motor_BIN1_PORT, Motor_BIN1_PIN);
		DL_GPIO_clearPins(Motor_BIN2_PORT, Motor_BIN2_PIN);
	}
	else {
		
		DL_GPIO_clearPins(Motor_BIN1_PORT, Motor_BIN1_PIN);
		DL_GPIO_setPins(Motor_BIN2_PORT, Motor_BIN2_PIN);
	}
	
	 R_PWM = abs(PWM);  //注意再用abs()的时候不要将需要绝对值化的数据定义为无符号类型
	
	DL_TimerG_setCaptureCompareValue(PWM_INST, R_PWM, DL_TIMER_CC_1_INDEX);    //可以在初始化文件中找到
	}
	
}


