#ifndef __KEY_H
#define __KEY_H

#include "ti_msp_dl_config.h"

uint8_t key_proc(void);
void key_tick(void);



#endif