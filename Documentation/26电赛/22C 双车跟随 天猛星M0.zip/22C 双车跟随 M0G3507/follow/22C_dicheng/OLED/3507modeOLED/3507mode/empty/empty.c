/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 
#include "ti_msp_dl_config.h"
#include "headfile.h"

int num=1;
uint8_t menuChoice=0;
int main(void)
{
    SYSCFG_DL_init();
    OLED_Init();
	  LED_Init();
    Timer_Init();
	  chaos_init();
	  LY_init();
	NVIC_EnableIRQ(GPIOB_INT_IRQn);
	    
//		jichu_speed=275;	
//	buzzerflag=1;
//	xunjiPidFlag=1;
//	chose_TI =1;
//	chaos_flag=1;
	
	
//	else if(queston_num==3){}
    while (1) 
		{		
			 encoder_count=real_distance();//编码器计数
		 chaos=chaos_pluserror();
			
			sprintf(text, "s:%d  ",chaos);
     OLED_ShowString(0,0,text,OLED_8X16);
//     sprintf(text, "l:%f   ",encoder_count);
//		 OLED_ShowString(0,16,text,OLED_8X16);		
//     sprintf(text, "l:%+05.0f   ",real_l_speed);
//			OLED_ShowString(0,16,text,OLED_8X16);	
//      sprintf(text, "r:%+05.0f   ",real_r_speed);
//			OLED_ShowString(0,32,text,OLED_8X16);
//      Motor_SetSpeed(275,275);
			
//      sprintf(text, "xunji:%d   ",Get_XunJi_WeightValue());
//			OLED_ShowString(0,48,text,OLED_8X16);

			                         
//    switch (menuChoice)//选择题目
//    {
//		  case 0:
//        menuChoice = main_menu();
//      break;
//      case 1:
//       menuChoice = menu1();
//      break;
//      case 2:
//       menuChoice =  menu2();
//      break;
//      case 3:
//       menuChoice =  menu3();
//      break;
//      case 4:
//       menuChoice =  menu4(); 
//    }
			
	
			
		OLED_Update();	
	  key_scan();		
    }
}
