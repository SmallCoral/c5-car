#include "headfile.h"

uint8_t xunjiPidFlag;
int jichu_speed=280;//0.3m/s 275   0.5m/s 460


// 循迹pid 0.3m/s p:2.3   循迹pid 0.5m/s p:4.5  d:0.1
 pid xunjiPid = {
    .kp = 4.3,
    .ki = 0,
    .kd = 11.0,
	  .Kff=0,
    .errorNew = 0,
    .errorLast = 0,
    .errorInt = 0,
    .errorIntMax = 1000,
    .target = 0,
    .actual = 0,
    .out = 0,
    .outMax = 500,
    .targetlast=0,
    .TickCount = 0,
    .flag = 0 
};

 pid chaosPid = 
{
    .kp = 0.75,
    .ki = 0,
    .kd = 0,
	  .Kff=0,
    .errorNew = 0,
    .errorLast = 0,
    .errorInt = 0,
    .errorIntMax = 1000,
    .target = 245,
    .actual = 0,
    .out = 0,
    .outMax = 500,
    .targetlast=0,
    .TickCount = 0,
    .flag = 0 
};

void PID_Cal(pid* pid)
{
	// 先计算当前误差
pid->errorNew = pid->target - pid->actual;

// 积分累加
pid->errorInt += pid->errorNew;

// 积分钳位
if (pid->errorInt > pid->errorIntMax)
    pid->errorInt = pid->errorIntMax;
else if (pid->errorInt < -pid->errorIntMax)
    pid->errorInt = -pid->errorIntMax;

float feedforward = pid->Kff * (pid->target- pid->targetlast);//前馈
// PID 输出
pid->out = pid->kp * pid->errorNew
         + pid->ki * pid->errorInt
         + pid->kd * (pid->errorNew - pid->errorLast)+feedforward;
         
// 保存当前误差供下次微分使用
pid->errorLast = pid->errorNew;
	// 调控限幅(角度)
    if(pid->out >= pid->outMax) 
    {
       pid->out = pid->outMax;
    }
    else if(pid->out < -pid->outMax)
    {
        pid->out = -pid->outMax ;
    }
  pid->targetlast=pid->target;
	// // 循迹pid
	// if(pid->flag == 0)
	// {
	// 	Motor_Set_ALL_Speed(trackMotorBaseSpeed+pid->out,trackMotorBaseSpeed-pid->out) ;
	// }
	// else if(pid->flag == 1)
	// {
	// 	Motor_Set_ALL_Speed(angleMotorBaseSpeed-pid->out,angleMotorBaseSpeed+pid->out) ;
	// }
}
	
		
//void PID_Tick(pid* pid) 
//{	
//	pid->TickCount++;
//	if(pid->TickCount > pid->Tick_Reload)
//	{
//		PID_Cal(pid); 
//		pid->TickCount = 0;
//	}
//}


// 10ms定时器执行一次的函数
void Task_10ms(void) 
{
	// 获取循迹的实际值
    xunjiPid.actual =Get_XunJi_WeightValue();
	//	// 循迹pid
    if(xunjiPidFlag == 1)
    {
        // 计算出循迹的out
     PID_Cal(&xunjiPid);
     Motor_SetSpeed(jichu_speed+xunjiPid.out+leftturn_speed-chaosPid.out,jichu_speed-chaosPid.out-xunjiPid.out+rightturn_speed);
    }

 
////  // 角度pid
//    stAnglePid.actual = Get_JY61Yaw() ; 
//    if(anglePidFlag == 1)
//    {
//         // 计算出循迹的out
//        PID_Cal(&stAnglePid);
//       Motor_Set_ALL_Speed(angleMotorBaseSpeed-stAnglePid.out,angleMotorBaseSpeed+stAnglePid.out) ;
//  
//    }
}