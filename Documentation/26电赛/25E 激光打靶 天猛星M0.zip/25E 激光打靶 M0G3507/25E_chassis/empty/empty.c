/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

#include "ti_msp_dl_config.h"
#include <bsp_system.h>

int IT_Flag_1 = 0;

char buffer[20];

float gray_error = 0.0f;

int main(void)
{
    SYSCFG_DL_init();
	
		NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);   //注意定时器外设的中断已经在图形化配置了，并且已经在上面的初始化中初始化了，所以这里只需要打开CPU中断
	
		OLED_Init();
		
		Motor_Init();
	
		JY_Initt();
	
		DL_Timer_startCounter(TIMER_0_INST);  //开启定时器计数
	
		Car_setspeed(220);  //设置初始速度
	
	
    while (1) {		

			menu_operation(); //菜单函数
			
			JY60_data_proc();   //处理JY901发送过来的数据包
			
			
	
			
    }
}



void TIMER_0_INST_IRQHandler(void) {
	
	uint32_t interuput = DL_TimerG_getPendingInterrupt(TIMER_0_INST);
	
	static uint8_t xunji_tim_gap = 0;
	
	if (interuput == DL_TIMER_IIDX_LOAD) { 
		
		//每隔10ms扫描一次按键， 消抖
		key_tick();
		
		//每隔10ms读取一次灰度权值
		gray_error = get_sensor_actual();
		
		//每10ms计算一次角度值
		JY_Angle = JY_angle_error();   
		
		
		
		//电机模式切换
		if (motor_state == 0) {
			
			Motor_Set_PWM(1, 0);
			Motor_Set_PWM(2, 0);
			
		}
		else if (motor_state == 1) {
			
			xunji_tim_gap++;
			
			//每隔20ms进行一次循迹PID的调控
			if (xunji_tim_gap >= 3) {
				
				xunji_tim_gap = 0;
				PID_Xunji();
			}
			
			
		}
		else if (motor_state == 2) {
			
			Turn_Angel();
		}
		
		
		
		
		
		if (DL_Timer_getRawInterruptStatus(TIMER_0_INST, DL_TIMER_INTERRUPT_LOAD_EVENT)) {
					IT_Flag_1 = 1;  // 记录"发生过更新事件" 
        // 确认记录后才手动清标志
        DL_Timer_clearInterruptStatus(TIMER_0_INST, DL_TIMER_INTERRUPT_LOAD_EVENT);
    }
		
	}
	
}


