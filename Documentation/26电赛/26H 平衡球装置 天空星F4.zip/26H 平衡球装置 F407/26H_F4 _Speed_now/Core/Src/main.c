/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "bsp_system.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint8_t IT_Flag_1 = 0;

char buffer[30];

int num  = 1;

uint8_t Order[3] = {0x01, 0x36, 0x6B}; //读取X轴电机坐标的指令

uint8_t tim_count = 0;;

int32_t R_gap = 0;
int32_t L_gap = 0;
int left_speed=0,right_speed=0;
//int16_t 

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_TIM9_Init();
  MX_USART3_UART_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
	
	OLED_Init();
	
	Motor_Init();
	
	Encode_Init();
	
	Motor_X_Init();
	
	Buffer_Init();
	Maxicam_Init();
	
	HAL_TIM_Base_Start_IT(&htim1);
	
	//Car_setspeed(320);  //设置平均速度
	
	//Contron_X_Speed(1, 0);
	
	//	Contron_X_Position(0, 20, 100, false);  //100 -> 3.6  50 -> 1.8

//	Motor_Set_PWM(1, 200);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		
		//获取灰度权值
		 Get_XunJi_WeightValue();
			
			//停车判断
			if(tim_count>=3)
			{	
				if(Get_AllXunJi_Value()==195||Get_AllXunJi_Value()==227||Get_AllXunJi_Value()==199)
				{
					motor_state =0;
				}
			}
		
		menu_operation();

		
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 84;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

//每5ms读取触发一次
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	
	static uint8_t Tx_count = 0;
	
	static uint8_t inter_tim = 0;
	
	static uint8_t out_tim = 0;
	
	static uint8_t wait_count = 0;
	
	static uint8_t maixcam_count = 0;
	
	static uint8_t xunji_count = 0;
	
	if (htim == &htim1) {
		
		
		
		
			//时间显示
			if (motor_state == 1) {
				
				wait_count++;
				if (wait_count >= 200) {
					
					wait_count = 0;
					tim_count++;
				}
			}
		
		
		
		
		
		
	/*----------底层处理部分---------*/	
		
		key_tick();
		
			
		maixcam_count++;
			
			if (maixcam_count >= 4) {
				
				maixcam_count = 0;
				Maxicam_Data_Handle();
			}
		
			
		
		Tx_count++;
		if (Tx_count >= 2) {
			
			Tx_count = 0;
			HAL_UART_Transmit_DMA(&huart3, (uint8_t *)Order, sizeof(Order));
		}
		motor_complete_data();
		
		
	/*-------------Keep_Balcance-------------*/	
		
		best_hard();
		
		
	if (balance_state == 1) {
		
		
		
		out_tim++;
		if (out_tim >= 4) {
			
      out_tim = 0;
			Keep_Blance_out();
		}
		
		
		inter_tim++;
		if (inter_tim >= 3) {
			
			inter_tim = 0;
			trace_balance_inter();
		}
		
	}

		
		
		
		
		/*-----------------循迹调控--------------------*/
			
					xunji_ti_chose();  //不同题目循迹参数的选择
	
	
			
			
					//获取灰度权值
		 Get_XunJi_WeightValue();
			
			//停车判断
			if(tim_count>=3)
			{	
				if(Get_AllXunJi_Value()==195||Get_AllXunJi_Value()==227||Get_AllXunJi_Value()==199)
				{
					motor_state =0;
				}
			}
				

			
			
			//循迹模式
			if (motor_state == 0) {
				
				Motor_Set_PWM(1, 0);
				Motor_Set_PWM(2, 0);
				
				
			}
			else if (motor_state == 1) {				
				
				xunji_count++;
					if (xunji_count >= 2) {
						
						xunji_count = 0;
						
									 left_speed=read_left_encoder();
	 right_speed=read_right_encoder();
	 location_left+=abs(left_speed);
	 location_right+=abs(right_speed);
	 location=(location_left+location_right)/2;
						
						Task_10ms();	
					}
					
			}
		

		

		
		if (__HAL_TIM_GET_FLAG(&htim1, TIM_FLAG_UPDATE) == 1) {
			
			IT_Flag_1 = 1;
			__HAL_TIM_CLEAR_FLAG(&htim1, TIM_FLAG_UPDATE);
		}
		
	}
	
	
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
