#ifndef __KEY_H
#define __KEY_H

#include "ti_msp_dl_config.h"

typedef struct keys {
	
	uint32_t key_sta;
	uint32_t key_judge;
	uint32_t key_single;
	
	uint32_t key_press;
	uint32_t key_long;
	
}key_E;

extern key_E key[4];
extern int num1;//试验作用

uint8_t key_scan(void);
void key_10mstick(void);

#endif