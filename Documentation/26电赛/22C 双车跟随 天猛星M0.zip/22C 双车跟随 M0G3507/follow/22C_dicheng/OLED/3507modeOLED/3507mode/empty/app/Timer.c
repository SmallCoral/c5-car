#include "headfile.h"

float real_l_speed,real_r_speed;
uint16_t chaos,old_chaos;
uint16_t buzzer_count;
uint32_t chaos_count;
uint8_t a,chaos_flag;

void Timer_Init()
{
    // 配置 TIM0 中断
  NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
	DL_TimerG_startCounter(TIMER_0_INST);
	DL_TimerG_startCounter(PWM_0_INST);
}

//定时器的中断服务函数 已配置为10ms的周期
void TIMER_0_INST_IRQHandler(void)//10ms进一次
{
	mytime_ms++;
  Task_10ms(); 
  key_10mstick(); 
  real_l_speed=real_speed(1);	
	real_r_speed=real_speed(2);
	Get_XunJi_WeightValue();
  get_sensor_actual();	
    if(buzzerflag == 1)
     {
       buzzer_count++;
			 buzzer_On();
       if(buzzer_count >= 30)
       {
				 buzzer_count=0;
         buzzerflag =0;
         buzzer_Off();
       } 
		 }

		 if(xunjiPidFlag==1)
     {       	chaos_count++;
			 if(chaos_count>=3)//30ms
			{
				bad_count++;
	     chaos_count=0;
			chaosPid.actual=chaos;	
				if(chaos_flag==1&&chaos<=395&&chaos>=25)//&&chaos>=25
	    {	
			PID_Cal(&chaosPid);
	    }
//       if(chaos>=250){jichu_speed+=10;if(jichu_speed>=400){jichu_speed=400;}else if(jichu_speed<=100){{jichu_speed=100;}}}	
//       else if(chaos<=240){jichu_speed-=10;if(jichu_speed>=400){jichu_speed=400;}else if(jichu_speed<=100){{jichu_speed=100;}}}	
      }
		 }
 
     
//    //如果产生了定时器中断
//    switch( DL_TimerG_getPendingInterrupt(TIMER_0_INST))
//    {
//        case DL_TIMERG_IIDX_ZERO://如果是0溢出中断

//            break;
//	
//        default://其他的定时器中断
//            break;
//    }
}


