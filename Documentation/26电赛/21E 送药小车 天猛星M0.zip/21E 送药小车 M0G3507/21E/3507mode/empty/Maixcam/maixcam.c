/*  

数据包格式: 包头： 0xAA 0x55

数据内容： 四个int16_t 类型的坐标点， 每个点的各个坐标由两个uint8_t 数据组成。  注意：数据发送是以小端格式发送的

包尾：0x17 转换为十进制为23， 表示数据包的总长度，可以用于检测数据包长度是否合格

*/



#include <maixcam.h>
#include <Buffer_Do.h>
#include <bsp_system.h>

uint32_t Turn;


rbuffer_t Pack_Buffer;

uint32_t length; 
uint16_t redundant;
int8_t rc;


static uint8_t _abuffer[256];




//初始化缓冲区，设置其大小和区域, 开启接收中断
void Buffer_Init(void) {
	
	rbuffer_init(&Pack_Buffer, _abuffer, sizeof(_abuffer));
}

/* 
	首先
*/

void Maxicam_Data_Handle(void) {
	
	//char buffer[20] = {0};
	
	rc = -1; ////默认数据包格式有误
	redundant = 0x00;  //获取赘余数据
	uint8_t ass_buffer[128] = {0x00};  //创立原始缓冲区，用于数据的校验
	uint8_t use_buffer[9] = {0x00};
	 	
	
	 length = rbuffer_data_len(&Pack_Buffer);
	
	if (length == 0) {
		return;
	}
	
	//防止数据长度越界
  	length = (length >= sizeof(ass_buffer))? sizeof(ass_buffer) : length;  
	
	//将主缓冲区的数据复制一份到副缓冲区中
	rbuffer_peek(&Pack_Buffer, ass_buffer, length);  
	
	//判断数据包是否校验成功, 注意这里校验数据包我是校验到了第一个完整的数据包，在解码部分我想就读取这一个完整的数据包.
	rc = verify_Pack(ass_buffer, length, &redundant);  
	
	//删去赘余数据,不会删去包头
	if (redundant > 0) {
		
		rbuffer_del(&Pack_Buffer, redundant);   //这样的删除数据与下面的删除数据联合起来，相当于没读取一次删去缓冲区中这次已经读取的数据
	}
	
	//解码
	//如果数据包格式正确则开始拆解数据包
	if (rc == 0) {
		
		packet_decode(&ass_buffer[redundant], length-redundant, use_buffer, sizeof(use_buffer));  //将有效数据赋予给use_buffer

		
		//Turn = ((uint32_t)use_buffer[6] << 24) | ((uint32_t)use_buffer[5] << 16) | ((uint32_t)use_buffer[4] << 8) | ((uint32_t)use_buffer[3]);
		
		
		memcpy(&Turn, &use_buffer[3], 4);   // 直接按小端序拷贝4字节
		
		
		if (Turn == 1) {
			
			 CAM_COMMAD = WAIT_TURN_LEFT;
			 DL_GPIO_clearPins(LED_T_L_PORT, LED_T_L_PIN);
			 DL_GPIO_setPins(LED_T_R_PORT, LED_T_R_PIN);
		}
		else if (Turn == 2) {
			
			CAM_COMMAD = WAIT_TURN_RIGHT;  
			 DL_GPIO_setPins(LED_T_L_PORT, LED_T_L_PIN);
			 DL_GPIO_clearPins(LED_T_R_PORT, LED_T_R_PIN);
		}
		
		
		//这里没有用，因为当他识别到目标数字时候才会发送数据
		else {
			
			CAM_COMMAD = ERROR_DATA;
				DL_GPIO_setPins(LED_T_L_PORT, LED_T_L_PIN);
			 DL_GPIO_setPins(LED_T_R_PORT, LED_T_R_PIN);
			
		}

		
		
		//每读取一次数据包就清除一次所有已读的数据, 有问题，没有管第一个好的数据包后面的别的数据包，而是直接把这心清除了
		rbuffer_del(&Pack_Buffer, 9); 
			
	}
	
	//当rc = -3时候包尾出现错误，此时直接清除整个缓冲区，不然错误的数据包无法处理会导致缓冲区堵塞
	else if (rc == -3){
		
		rbuffer_del(&Pack_Buffer, redundant + 9);   
		//rbuffer_reset(&Pack_Buffer);
		
	}
	
	//当rc = -2时候表示已经检测到数据包的包头了，直接退出函数等待缓冲区继续接收数据
	else if (rc == -2) {
		
		return;
	}
	
}


