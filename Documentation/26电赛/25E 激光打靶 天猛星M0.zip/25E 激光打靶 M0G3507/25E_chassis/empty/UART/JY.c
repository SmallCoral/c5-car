#include <JY.h>
#include <bsp_system.h>

float yaw;
int16_t Gz;


float Angle_gyro = 0.0;

float JY_Angle;

//JY60串口5参数
uint8_t serial_JY60_Flag = 0;  //0表示可以开始接收数据， 1表示数据正在处理
uint8_t JY60_Rxbuffer[20];
uint16_t pJY60_RxBuffer = 0;


void JY_Initt(void) {

		NVIC_ClearPendingIRQ(JY_INST_INT_IRQN);  //上电时候首先清空该中断, 不能让使能中断之前的操作（数据）触发中断
    NVIC_EnableIRQ(JY_INST_INT_IRQN);  //开启该中断, 由于初始化里面已经开启了接收中断所以这里只需要开启CPU的处理中断请求就行

    DL_UART_Main_receiveData(JY_INST);  //防止中断初始化前标志位被错误置为导致中断后续无法触发		
}



float JY_angle_error(void) {


	float raw_changeg = yaw * 0.01f;  //确定符号，当小车向右边偏移时候，灰度传感器得出的角度为正值,raw_change也为正值则下面的符号改为＋

	
	Angle_gyro = Angle_gyro + raw_changeg;  //姿态传感器所计算得到得角度值


	return Angle_gyro;
}



void UART3_IRQHandler(void) {
	
		//JY60数据接收
	static uint8_t JY_RxState = 0;

    uint32_t interrupt = DL_UART_Main_getPendingInterrupt(JY_INST);

    if (interrupt == DL_UART_MAIN_IIDX_RX) {

			uint8_t JY_Rxdata = DL_UART_Main_receiveData(JY_INST);

			if (JY_RxState == 0) {

				if(JY_Rxdata == 0x55){

					JY_RxState = 1;
					JY60_Rxbuffer[0] = JY_Rxdata;
				}
			}
			else if(JY_RxState == 1){

			//0x53，那这个包就是含有角度的数据, 0x53，那这个包就是含有角度的数据
					if (JY_Rxdata == 0x52  && serial_JY60_Flag == 0){
						JY_RxState = 2;
						JY60_Rxbuffer[1] = JY_Rxdata;	// 保存类型字节用于校验和计算
						pJY60_RxBuffer = 1;
					}
					else {
						JY_RxState = 0;
					}

				}
			else if (JY_RxState == 2) {

					if (pJY60_RxBuffer < 11) {		// 8字节数据 + 1字节校验和
						pJY60_RxBuffer++;
						JY60_Rxbuffer[pJY60_RxBuffer] = JY_Rxdata;
					
					}	

					if (pJY60_RxBuffer == 10) {		// 收满了，做校验
						uint8_t sum = 0;
//					for (int i = 0; i < 10; i++) {	// 类型(下标0) + 7字节数据
//						sum += JY60_Rxbuffer[i];
//					}
						sum = JY60_Rxbuffer[0] + JY60_Rxbuffer[1] + JY60_Rxbuffer[2] + JY60_Rxbuffer[3] + JY60_Rxbuffer[4] + JY60_Rxbuffer[5] + JY60_Rxbuffer[6] + JY60_Rxbuffer[7] + JY60_Rxbuffer[8] + JY60_Rxbuffer[9];
					
						if (sum == JY60_Rxbuffer[10]) {	// 校验通过
							JY_RxState = 0;
							serial_JY60_Flag = 1;
						} else {
							JY_RxState = 0;			// 校验失败，丢弃
						}
					}
				}
        
			}
}


void JY60_data_proc(void) {

	if (serial_JY60_Flag == 1) {

	if ((JY60_Rxbuffer[0] == 0x55) && (JY60_Rxbuffer[1] == 0x52)) {
							
			Gz = (int16_t)((int16_t)JY60_Rxbuffer[7]<<8 | JY60_Rxbuffer[6]); // 0x00 00    0x43[6]  0x55 [7]   0x0055 ->  0x5500 | 0x0043 = 0x5543
			yaw = ((float)Gz / 32768.0f) * 2000.0f;
		}

  else if ((JY60_Rxbuffer[0] == 0x55) && (JY60_Rxbuffer[1] == 0x53)) {

			Gz = (int16_t)((int16_t)JY60_Rxbuffer[7]<<8 | JY60_Rxbuffer[6]);
			yaw = ((float)Gz / 32768.0f) * 180.0f;
	}		

		serial_JY60_Flag = 0;

	}

}
