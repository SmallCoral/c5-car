#include "headfile.h"

char text[20];
uint8_t show_flag = 1;
uint32_t mytime_ms;
uint8_t queston_num;


int main_menu()
{

   uint8_t keyNum = 0;
   OLED_ShowString(12, 0, "T1", OLED_8X16);
   OLED_ShowString(12, 16, "T2", OLED_8X16);
   OLED_ShowString(12, 32, "T3", OLED_8X16);
   OLED_ShowString(12, 48, "T4", OLED_8X16);
   OLED_Update();

   while (1)
   {


      keyNum = key_scan();
      if (keyNum == 1)
      {
         show_flag++;
         if(show_flag==5)
         {show_flag=1;}//1到4循环
      }
      else if (keyNum == 2)
      {
         OLED_Clear();
         return (show_flag);
      }

      static uint32_t oldTick = 0;
      if (mytime_ms - oldTick > 20)//200ms
      {
         oldTick = mytime_ms;
         switch (show_flag)
         {
         case 1:
         {
            OLED_ShowString(0, 16, " ", OLED_8X16);
            OLED_ShowString(0, 32, " ", OLED_8X16);
            OLED_ShowString(0, 48, " ", OLED_8X16);
            OLED_ShowString(0, 0, "*", OLED_8X16);
            OLED_Update();
         }
         break;
         case 2:
         {
            OLED_ShowString(0, 0, " ", OLED_8X16);
            OLED_ShowString(0, 32, " ", OLED_8X16);
            OLED_ShowString(0, 48, " ", OLED_8X16);
            OLED_ShowString(0, 16, "*", OLED_8X16);
            OLED_Update();
         }
         break;
         case 3:
         {
            OLED_ShowString(0, 0, " ", OLED_8X16);
            OLED_ShowString(0, 16, " ", OLED_8X16);
            OLED_ShowString(0, 48, " ", OLED_8X16);
            OLED_ShowString(0, 32, "*", OLED_8X16);
            OLED_Update();
         }
         break;
         case 4:
				 { 
            OLED_ShowString(0, 0, " ", OLED_8X16);
            OLED_ShowString(0, 16, " ", OLED_8X16);
            OLED_ShowString(0, 32, " ", OLED_8X16);
            OLED_ShowString(0, 48, "*", OLED_8X16);
            OLED_Update();
         }
         break;
         }
	 
      }
   }
}

int menu1()
{
uint8_t keyNum = 0;
int i1 = 0;	
OLED_ShowString(0, 0, "T1", OLED_8X16);
OLED_Update();
while(1)
{
keyNum = key_scan();
chaos=read_chaos_value();
sprintf(text, "s:%d  ",chaos);
OLED_ShowString(0,32,text,OLED_8X16);
//sprintf(text, "kp:%.2f ",xunjiPid.kp);
//OLED_ShowString(0,48,text,OLED_8X16);
//sprintf(text, "kd:%.2f ",xunjiPid.kd);
//OLED_ShowString(64,32,text,OLED_8X16);
//	sprintf(text, "a:%d  ",a);//xunjiPid.kp
//OLED_ShowString(0,48,text,OLED_8X16);
	
sprintf(text, "l:%+05.0f   ",real_l_speed);
OLED_ShowString(0,48,text,OLED_8X16);
sprintf(text, "r:%+05.0f   ",real_r_speed);
OLED_ShowString(64,32,text,OLED_8X16);	
	
if(keyNum == 2)//按键2开始循迹
{
i1++;
i1%=2;
}
else if(keyNum == 1)//取消，退出
{
//OLED_Clear();
//return 0;
//xunjiPid.kp-=0.1;	
}
else if(keyNum == 4)//取消，退出
{
//xunjiPid.kd+=0.1;
	
}
else if(keyNum == 3)//取消，退出
{
	chaos_flag++;
	chaos_flag%=2;
//	xunjiPid.kd-=0.1;
}
if(i1==1)
{
xunjiPidFlag=1;
queston_num=1;
chose_TI=1;	
//if(Get_XunJi_WeightValue()==0||Get_XunJi_WeightValue()==1||Get_XunJi_WeightValue()==128){i1 =0;xunjiPidFlag=0;}



OLED_ShowString(0, 16, "start", OLED_8X16); 
OLED_Update();
}
else if (i1 == 0)
{
queston_num=0;	
xunjiPidFlag=0;
OLED_ShowString(0, 16, "stop  ",OLED_8X16);
Motor_SetSpeed(0, 0);
OLED_Update();
}
}			
}
//#######################################################第二题
int menu2()
{
uint8_t keyNum = 0;
	
OLED_ShowString(0, 0, "T2", OLED_8X16);
OLED_Update();

	
while(1)
{
keyNum = key_scan();
	
	
	 if (keyNum == 1)//取消
{
   OLED_Clear();
   return 0;
}
}	
	
	
}


int menu3()
{
uint8_t keyNum = 0;
	
   OLED_ShowString(0, 0, "T3", OLED_8X16);
   OLED_Update();

	
while(1)
{
keyNum = key_scan();
	
	
	 if (keyNum == 1)//取消
 {
   OLED_Clear();
   return 0;
}
}	
	
	
}


int menu4()
{
uint8_t keyNum = 0;
	
   OLED_ShowString(0, 0, "T4", OLED_8X16);
   OLED_Update();
	
while(1)
{
keyNum = key_scan();
	
	
	 if (keyNum == 1)//取消
 {
   OLED_Clear();
   return 0;
}
}	
	
	
}