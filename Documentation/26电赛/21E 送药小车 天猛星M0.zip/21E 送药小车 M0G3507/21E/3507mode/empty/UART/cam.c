#include <cam.h>
#include <bsp_system.h>


void CAM_Init(void) {
	
		NVIC_ClearPendingIRQ(CAM_INST_INT_IRQN);  //上电时候首先清空该中断, 不能让使能中断之前的操作（数据）触发中断
    NVIC_EnableIRQ(CAM_INST_INT_IRQN);  //开启该中断, 由于初始化里面已经开启了接收中断所以这里只需要开启CPU的处理中断请求就行

    DL_UART_Main_receiveData(CAM_INST);  //防止中断初始化前标志位被错误置为导致中断后续无法触发		
	
}


void CAM_INST_IRQHandler(void)  {
	
	
	
	uint32_t interrupt = DL_UART_Main_getPendingInterrupt(CAM_INST);	
	
	if (interrupt == DL_UART_MAIN_IIDX_RX) {
		
		uint8_t udata_Maxicam = DL_UART_Main_receiveData(CAM_INST);
		
		rbuffer_putchar(&Pack_Buffer, udata_Maxicam);
		
		
	}
	
}


