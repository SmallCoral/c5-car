#ifndef __MAIXCAM_H
#define __MAIXCAM_H

#include "ti_msp_dl_config.h"
#include <buffer.h>


extern int8_t rc;
extern uint32_t length;
extern uint16_t redundant;

extern rbuffer_t Pack_Buffer;







void Buffer_Init(void);

void Maxicam_Data_Handle(void);


#endif

