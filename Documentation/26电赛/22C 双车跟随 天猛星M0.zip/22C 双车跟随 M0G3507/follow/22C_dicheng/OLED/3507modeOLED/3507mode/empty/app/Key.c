#include "headfile.h"

int num1;//试验作用

key_E key[4];

uint8_t key_scan(void) {
	
	uint8_t temp = 0;
	
	if (key[0].key_single == 1) {
		
		key[0].key_single = 0;
		temp = 1;
		return temp;
	}
	
	if (key[1].key_single == 1) {
		
		key[1].key_single = 0;
		temp = 2;
		return temp;
	}
	
	
	if (key[2].key_single == 1) {
		
		key[2].key_single = 0;
		temp = 3;
		return temp;
	}
	
	
	if (key[3].key_single == 1) {
		
		key[3].key_single = 0;
		temp = 4;
		return temp;
	}
	
	return 0;
}


void key_10mstick(void) 
{	
	
	int i;
	
	key[0].key_sta = DL_GPIO_readPins(KEY_KEY1_PORT, KEY_KEY1_PIN);
	key[1].key_sta = DL_GPIO_readPins(KEY_KEY2_PORT, KEY_KEY2_PIN);
	key[2].key_sta = DL_GPIO_readPins(KEY_KEY3_PORT, KEY_KEY3_PIN);
	key[3].key_sta = DL_GPIO_readPins(KEY_KEY4_PORT, KEY_KEY4_PIN);
	
	for ( i = 0; i < 4; i++) 
{
		
	switch (key[i].key_judge) 
	{
		
		case 0:
			
		if(key[i].key_sta == 0) 
		{
			
			key[i].key_judge = 1;
		}		
		break;
		
		case 1:
			
		if (key[i].key_sta == 0) 
		{
			
			key[i].key_press = 0;
			key[i].key_long = 0;
			
			key[i].key_judge = 2;
		}		
		else 
		{
			key[i].key_judge = 0;   
		}
		break;
		
		case 2:
			
		if (key[i].key_sta != 0) 
		{
			
			if (key[i].key_long == 0) 
			{
				
				key[i].key_single = 1;
			}
			else if (key[i].key_long == 1) //写长按1s的内容
			{
				
				key[i].key_long = 0;
         if(i==0)//写按键1长按1s的内容
					 {
						 //num1--;
					 }
				 else if(i==1) //写按键2长按1s的内容
					 {
						 //num1--;
					 }
         else if(i==2)//写按键3长按1s的内容 
					 {
						 //num1--;
					 }
         else if(i==3)//写按键4长按1s的内容 
					 {
						 //num1--;
					 }
			}
			
			key[i].key_judge = 0;   //释放按键标志位
		}
		

			
		else 	if(key[i].key_sta == 0) //按键3
		{
			{
				
				key[i].key_press++;
				if (key[i].key_press >= 98) //1s
				{
					
					key[i].key_long = 1;
				}
			}
			
		}	
		break;
		
	}	
}	
}


