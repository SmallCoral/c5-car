#include "headfile.h"

uint8_t first_chaos=1;
uint8_t bad_count = 0;  // 连续突变计数

void chaos_init(void) {
	
	DL_Timer_startCounter(PWM_chaos_INST);  // 开始输出PWM来触发超声波
	
}

uint16_t read_chaos_value(void) 
{
uint16_t disval = DL_Timer_getCaptureCompareValue(CAPTURE_chaos_INST, DL_TIMER_CC_0_INDEX) * 0.17;
//if(disval>=350||disval<=50){disval=200;a=1;}else	{a=0;}
uint16_t last_disval=	disval;
	//if(disval>=345||disval<=145){disval=245;}	
return disval;
}

//uint16_t chaos_pluserror(void)
//{
//	uint16_t raw;
//raw=read_chaos_value();  
//if(first_chaos)
//{
//first_chaos=0;
//old_chaos=raw;
//return raw;
//if (raw == 0) {
//    first_chaos = 1;  
//    return 245;       
//}
//}
//uint16_t chaos_error=abs(raw-old_chaos);
//if(chaos_error>=150){return old_chaos;}
//else {old_chaos=raw;return raw;}

//}

uint16_t chaos_pluserror(void)
{
    uint16_t raw = read_chaos_value();
    
    
    // ----- 初次初始化 -----
    if (first_chaos) {
        first_chaos = 0;
        if (raw == 0) {
            // 初次读0，可能超声波未就绪，给默认值245（24.5cm），并保持 first_chaos=1 以便下次重试
            first_chaos = 1;
            old_chaos = 245;
            return 245;
        } else {
            old_chaos = raw;
            return raw;
        }
    }
    uint16_t delta = abs((int)raw - (int)old_chaos);
    
    if (delta >= 150) {
        // 突变，返回旧值，但累计连续突变次数

        if (bad_count >= 2) {   
            bad_count = 0;
            old_chaos = raw;
            return raw;
        }
        return old_chaos;
    } else {
        bad_count = 0;          // 恢复正常，清零计数
        old_chaos = raw;
        return raw;
    }
}