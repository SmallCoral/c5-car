#ifndef __CAM_H
#define __CAM_H


#include "ti_msp_dl_config.h"


void CAM_Init(void);

#endif
