/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define M_2_Pin GPIO_PIN_2
#define M_2_GPIO_Port GPIOE
#define L3_Pin GPIO_PIN_3
#define L3_GPIO_Port GPIOE
#define R_2_Pin GPIO_PIN_4
#define R_2_GPIO_Port GPIOE
#define BIN2_Pin GPIO_PIN_5
#define BIN2_GPIO_Port GPIOC
#define BIN1_Pin GPIO_PIN_1
#define BIN1_GPIO_Port GPIOB
#define AIN1_Pin GPIO_PIN_8
#define AIN1_GPIO_Port GPIOE
#define KEY_1_Pin GPIO_PIN_9
#define KEY_1_GPIO_Port GPIOE
#define AIN2_Pin GPIO_PIN_10
#define AIN2_GPIO_Port GPIOE
#define KEY_2_Pin GPIO_PIN_11
#define KEY_2_GPIO_Port GPIOE
#define KEY_3_Pin GPIO_PIN_12
#define KEY_3_GPIO_Port GPIOE
#define KEY_4_Pin GPIO_PIN_13
#define KEY_4_GPIO_Port GPIOE
#define R_3_Pin GPIO_PIN_14
#define R_3_GPIO_Port GPIOE
#define L2_Pin GPIO_PIN_15
#define L2_GPIO_Port GPIOE
#define L1_Pin GPIO_PIN_12
#define L1_GPIO_Port GPIOB
#define R_1_Pin GPIO_PIN_0
#define R_1_GPIO_Port GPIOE
#define M_1_Pin GPIO_PIN_1
#define M_1_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
