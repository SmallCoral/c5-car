/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 

#include "ti_msp_dl_config.h"
#include <bsp_system.h>

uint8_t IT_Flag_1;

float XunJi_Value = 0.0f;


char buffer[20];

int main(void)
{
    SYSCFG_DL_init();
	
		NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);   //注意定时器外设的中断已经在图形化配置了，并且已经在上面的初始化中初始化了，所以这里只需要打开CPU中断
	
		OLED_Init() ;
	
		Motor_Init();
	
		JY_Initt();
	
		CAM_Init();  //初始化串口中断
		Buffer_Init();  //初始化缓冲区
	
	
		DL_Timer_startCounter(TIMER_0_INST);  //开启定时器计数
	
		Car_setspeed(250);  //设置小车的基础速度
	
//			Motor_Set_PWM(1, 130);
//			Motor_Set_PWM(2, -110);			2s

	
    while (1) {		
			

			Send_Room();  //实时检测小车是否需要进入药房
			
			load_medicine();  //实时检测药品是否被取走

			JY60_data_proc();  //实时处理JY901接收到的数据包
		
			Maxicam_Data_Handle();  //实时处理maixcam2 接收到数据

			menu_operation();
			
    }
}

void TIMER_0_INST_IRQHandler(void) {
	
	
	uint32_t interuput = DL_TimerG_getPendingInterrupt(TIMER_0_INST);
	
	static uint8_t tim_out = 0;

	static uint8_t send_delay_cnt = 0;

	static uint8_t car_gray_delay_cnt = 0;

	static uint8_t car_Turn_delay_cnt = 0;
	
	static uint8_t count_gray = 0;
	
	static uint8_t stop_to_swing = 0;
	
	static uint8_t room_state_return_0 = 0;
	
	static uint8_t room_state_return_1 = 0;
	
	
	if (interuput == DL_TIMER_IIDX_LOAD) { 
		
		
		
		key_tick();
		
		JY_Angel = JY_angle_error();

		XunJi_Value = get_sensor_actual();  //放在定时器中读取， 防止motor_stae状态切换无法状态切换
	
		
//正常巡线PID		
		if (motor_state == 1) {
			
			tim_out++;
			 gyro_control_inter();  //每隔10ms PID调节一次内环
			
			
			//每隔20msPID调控一次外环  
			if (tim_out >= 2) {
				
				tim_out = 0;
				gray_control_out();  
			}		
		}

		else if (motor_state == 2) {

			Car_Turn();
		}
		
		else if (motor_state == 3) {
			
			swing_vision();
		}
		
		else if (motor_state == 4) {
			
		 car_Trun_Down();
		}
		
		else if (motor_state == 5) {
		
			car_come_back();
		}
		
		else if (motor_state == 6) {
			
			last_state();
		}

		else if (motor_state == 0) {
			
			tim_out = 0;
			Motor_Set_PWM(1, 0);
			Motor_Set_PWM(2, 0);
		}
		
		
		
// 开车延时
	if (send_delay_begain == 1 && send_delay_use == 1) {
		send_delay_cnt++;
		if (send_delay_cnt >= 200) {
			send_delay_use = 0;
			send_delay_cnt = 0;
			motor_state = 1;   //小车进入巡线状态
		}
	}
	else {
		send_delay_cnt = 0;
	}

//转弯延时
	if (car_turn_delay_begain == 1 && car_turn_delay_use == 1) {
		car_Turn_delay_cnt++;
		if (car_Turn_delay_cnt >= 180) {   //170
			car_turn_delay_begain = 0;
			car_turn_delay_use = 0;
			car_Turn_delay_cnt = 0;
			motor_state = 1;   //小车进入巡线状态
			CAM_COMMAD = COMPLET_TURN;   //小车完成转弯状态
			
			car_gray_delay_use = 1;
		}
	}
	else {
			car_Turn_delay_cnt = 0;
	}


//灰线停车	
	if (car_gray_delay_begain == 1 && car_gray_delay_use == 1) {
		car_gray_delay_cnt++;
		motor_state = 0;
		if (car_gray_delay_cnt >= 30) {
			car_gray_delay_begain = 0;
			car_gray_delay_use = 0;
			car_gray_delay_cnt = 0;
			XUN_COMMAD = COMPLET_GRAY_STOP;   //完成灰度循迹停车状态
			motor_state = 2;         // 延时到，启动
			
			if (CAM_COMMAD == WAIT_TURN_LEFT ) {
				
				if (room_state == 3 && last_Turn == 20) {
					Angle_Bias = 0.0f;  //上一次右转，这一次左转
				}
				else if (room_state == 3 && last_Turn == 10){
					Angle_Bias = 180.0f;  //上一次左转， 这一次左转
				}
				else {
					Angle_Bias = 90.0f;  //这一次左转
				}
				
			}
			else if (CAM_COMMAD == WAIT_TURN_RIGHT) {
				
				if (room_state == 3 && last_Turn == 10) {
					
					Angle_Bias = 0.0f;  //上一次左转，这一次右转
				}
				else if (room_state == 3 && last_Turn == 20) {
					
					Angle_Bias = -180.0f;  //上一次右转， 这一次右转
				}
				else {
					
					Angle_Bias = -90.0f;  //这一次右转
				}
				
			}
			
		}
	}
	else {
		car_gray_delay_cnt = 0;
	}

	
	
	//数病房延时, 注意此停车必须大于灰线停车
		if (gray_count_begain == 1) {
			
			count_gray++;
			if (count_gray >= 100) {
				
				count_gray = 0;
				room_state++;
				gray_count_begain = 0;
			}
		}
		
		
	//对于远端病房的特殊处理， 到达标号牌处延时
		//注意当小车未识别到目标数字时候才会开始进入摆动寻找模式
		if (room_state == 2 && room_state_return_0 == 0 && CAM_COMMAD == NONE_DATE) {

			stop_to_swing++;
			if (stop_to_swing >= 90) {
				
				stop_to_swing = 0;
				room_state_return_0 = 1;
				motor_state = 3;  //进入状态3， 开始摆动识别标号
			}
		}			
		
//		if (room_state == 3 && room_state_return_1 == 0) {
//			
//				stop_to_swing++;
//			if (stop_to_swing >= 250) {
//				
//				stop_to_swing = 0;
//				room_state_return_1 = 1;
//				motor_state = 3;  //进入状态3， 开始摆动识别标号
//			}
//		}
		
		
	if (DL_Timer_getRawInterruptStatus(TIMER_0_INST, DL_TIMER_INTERRUPT_LOAD_EVENT)) {
					IT_Flag_1 = 1;  // 记录"发生过更新事件"
        // 确认记录后才手动清标志
        DL_Timer_clearInterruptStatus(TIMER_0_INST, DL_TIMER_INTERRUPT_LOAD_EVENT);
    }
		
	}
	

}


